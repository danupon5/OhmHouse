from pathlib import Path
import json,csv,subprocess,fitz,zipfile
root=Path('/workspace/shared/downloads/OhmHouse-Ceilings-Final-20261017');ev=root/'eaves/OhmHouse_Eaves_Ventilated_Scope_A3.svg'
s=ev.read_text()
changes={
'แผ่นขนาด 120 × 60 ซม. ตามที่ผู้ใช้ระบุ • แยกวัสดุจากฝ้าลาน • หน้านี้เป็นแผนตรวจระยะก่อนสรุปซื้อ':'เฌอร่า มีรูระบายอากาศ เว้นร่อง 3 นิ้ว • 60 × 120 ซม. หนา 4 มม. • 58 บาท/แผ่น • ฝ้าเอียงตามจั่ว',
'ต้องตรวจความกว้างช่วงยื่น แนวราบ/ลาด พื้นที่ซ้ำกับลาน และราคา ก่อนยืนยันจำนวนสั่งซื้อชายคา':'ยืนยันฝ้าเอียงตามจั่วและราคา 58 บาท/แผ่นแล้ว • ยังต้องตรวจช่วงยื่นจริงและพื้นที่ซ้ำกับลานก่อนสั่งซื้อ',
'ด้าน 60 ซม. เรียงต่อไปตามแนวยาวชายคา • ต้องยืนยันแนวติดตั้งจริง':'ด้าน 60 ซม. เรียงตามแนวลาดจั่ว • ด้าน 120 ซม. พาดจากผนังออกชายคา',
'สถานะจำนวนสั่งซื้อ: รอตรวจแนวและระยะ':'ฝ้าเอียงตามจั่ว: ยืนยันแล้ว / รอตรวจช่วงยื่น',
'1. ฝ้าราบ หรือฝ้าเอียงตามแนวจั่ว':'1. ยืนยันแล้ว: ฝ้าเอียงตามจั่ว ไม่ใช่ฝ้าราบ',
'4. รุ่น ความหนา และราคาแผ่นมีรู 120 × 60 ซม.':'4. ยืนยันรุ่นเฌอร่า หนา 4 มม. ราคา 58 บาท/แผ่น',
'ราคาส่วนชายคายังไม่รวมในยอดนี้ • แผ่นมีรูแยกชนิดจากแผ่นลายร่องของลาน':'แผ่นชายคา 58 บาท/แผ่น ยังไม่รวมยอดจนทราบจำนวน • แยกวัสดุจากฝ้าลาน',
'ถ้าช่วงยื่น 1.00 ม. และใช้แผ่นพาดขวาง 1.20 ม.':'ตัวอย่างเท่านั้น: หากช่วงยื่นตามแผ่นเท่ากับ 1.00 ม.',
'แผ่นหนึ่งปิดได้ประมาณ 0.60 × 1.00 = 0.60 ตร.ม.':'การตัดต้องวัดจากผนังถึงขอบฝ้าจริงตามแนวติดตั้ง',
'จึงต้องถอดเป็นช่วง ไม่ใช้พื้นที่แผ่นเต็มหารอย่างเดียว':'จำนวนซื้อจึงต้องถอดเป็นช่วงและบากมุม ไม่หารพื้นที่อย่างเดียว'}
for a,b in changes.items():s=s.replace(a,b)
ev.write_text(s)
cover=root/'Ceiling_Purchase_Summary_A3.svg';s=cover.read_text().replace('โซน 4 ชายคามีรู 120 × 60 ซม.: รอตรวจแนวและระยะ ยังไม่รวมจำนวน / ราคา','โซน 4 ชายคาเฌอร่า มีรู หนา 4 มม. เอียงตามจั่ว 58 บาท/แผ่น: รอตรวจจำนวน');cover.write_text(s)
for src,dst in [(ev,root/'eaves/OhmHouse_Eaves_Ventilated_Scope_A3.pdf'),(cover,root/'Ceiling_Purchase_Summary_A3.pdf')]:subprocess.run(['inkscape',str(src),'--export-type=pdf','--export-filename='+str(dst)],check=True,capture_output=True)
s=json.loads((root/'summary.json').read_text());s['eaves'].update({'material':'SHERA ventilated smooth soffit, 3-inch groove','product_code':'60322144','thickness_mm':4,'unit_price_thb':58,'roof_alignment_confirmed':'sloped along gable','orientation_confirmed':'60 cm repeated along sloped gable; 120 cm wall-to-eave','quantity_status':'sloped installation and product/price confirmed; actual eave widths and porch overlap require measurement'});s['eaves'].pop('orientation_provisional',None);(root/'summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2))
with (root/'purchase-list.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f));fields=list(rows[0])
for r in rows:
 if r['zone'].startswith('ชายคา'):r['material']='เฌอร่า มีรู เว้นร่อง3นิ้ว 4มม. เอียงตามจั่ว';r['unit_price_thb']='58'
with (root/'purchase-list.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
out=fitz.open()
for f in [root/'Ceiling_Purchase_Summary_A3.pdf',root/'interior/OhmHouse_Interior_Ceiling_A3_Plan_and_Cuts.pdf',root/'bathrooms/OhmHouse_Bathroom_Ceiling_A3.pdf',root/'porch/OhmHouse_Porch_Ceiling_A3_Plan_and_Cuts.pdf',root/'eaves/OhmHouse_Eaves_Ventilated_Scope_A3.pdf']:out.insert_pdf(fitz.open(f))
assert len(out)==11;out.save(root/'OhmHouse_All_Ceilings_Updated.pdf')
with (root/'README.md').open('a') as f:f.write('''\n## ยืนยันชนิดชายคาและแนวติดตั้งล่าสุด\n\nผู้ใช้เลือกเฌอร่าแผ่นฝ้าระบายอากาศผิวเรียบเว้นร่อง 3 นิ้ว รหัส 60322144 ขนาด 60 × 120 ซม. หนา 4 มม. ราคา 58 บาทต่อแผ่น และยืนยันฝ้าเอียงตามแนวจั่วแล้ว ข้อมูลนี้แทนสถานะรอรุ่น/ราคา/แนวฝ้าในบันทึกก่อนหน้า ยังไม่ยืนยันจำนวนชายคาเพราะช่วงยื่นและพื้นที่ซ้ำกับลานต้องตรวจจากแบบรายละเอียด/หน้างาน ข้อมูล GLB ไม่สามารถดาวน์โหลดตรวจได้ในรอบนี้ จึงไม่สร้างจำนวนซื้อที่อ้างว่าเป็นผลวัดครบจากโมเดล\n''')
(root/'source/confirm-sloped-eaves.py').write_text(Path('/workspace/scratch/confirm-sloped-eaves.py').read_text())
with zipfile.ZipFile(root/'OhmHouse_Ceilings_Backup_2026-10-17.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in root.rglob('*'):
  if not f.is_file() or f.suffix=='.zip' or f.name.startswith('page-') or f.name in ['preview.png','summary-preview.png']:continue
  z.write(f,f.relative_to(root))
print('Confirmed SHERA 4mm 58 THB/sheet sloped gable in PDF, CSV, JSON and ZIP; quantity not fabricated.')
