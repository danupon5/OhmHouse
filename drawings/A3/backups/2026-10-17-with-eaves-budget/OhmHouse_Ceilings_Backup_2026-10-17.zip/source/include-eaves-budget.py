from pathlib import Path
import math,json,csv,subprocess,fitz,zipfile
root=Path('/workspace/shared/downloads/OhmHouse-Ceilings-Final-20261017')
source_area=43.28;assumed_width=1.;repeat=.6;pitch=28.438356311680547
base=math.ceil(source_area/(assumed_width*repeat))
contingency_factor=1/math.cos(math.radians(pitch))
working=math.ceil(source_area/(assumed_width*repeat)*contingency_factor);allowance=math.ceil(working*.10);budget=working+allowance
assert (base,working,allowance,budget)==(73,83,9,92)
price=58;cost=budget*price;total_boards=63+budget;total_cost=12048+cost
assert (cost,total_boards,total_cost)==(5336,155,17384)
exec(Path('/workspace/scratch/ohm-a3/build.py').read_text().split('p=Page(1,')[0])
def footer(pg,code):
 pg.items=[s.replace(f'A–{pg.num:02} / 06',code).replace('ชุดแปลนประกอบการวางแผน • อ้างอิง Pascal V384 / ข้อมูล 11 ก.ย. 2026','ชุดรวมวัสดุฝ้า • ชายคาเป็นประมาณการเผื่องบ แยกจากรายการที่มีผังตัด').replace('สร้างชุดเอกสาร 3 ต.ค. 2026','สำรองฉบับรวมชายคา 17 ต.ค. 2026').replace('ระยะตามไฟล์แบบ ไม่ใช่ระยะสุทธิหลังฉาบ • ตรวจหน้างานก่อนก่อสร้างหรือสั่งผลิต','ต้องตรวจระยะยื่นจริงและพื้นที่ซ้ำกับลานก่อนสั่งชายคา • ไม่อ้างว่าเป็นยอดวัดครบจากโมเดล 3D') for s in pg.items]
p=Page(1,'ชายคารอบบ้าน / ฝ้าเอียงตามจั่ว','เฌอร่า มีรูระบายอากาศ เว้นร่อง 3 นิ้ว • 60 × 120 ซม. หนา 4 มม. • ราคา 58 บาทต่อแผ่น')
p.text(20,45,'ประมาณการเผื่องบ: 92 แผ่น = 5,336 บาท',4.6,bold=True)
p.text(20,58,'เป็นจำนวนเผื่อเบื้องต้น ยังไม่ใช่ผังตัดชายคาครบทุกช่วง',3.1,bold=True,color='#a35c2d')
p.text(20,78,'แนววางที่ผู้ใช้เลือก',3.8,bold=True)
p.text(20,89,'ฝ้าเอียงตามแนวจั่ว • ด้าน 120 ซม. พาดจากผนังออกชายคา',2.9)
p.text(20,99,'ด้าน 60 ซม. เรียงต่อไปตามแนวลาดจั่ว / แนวยาวชายคา',2.9)
x=30;y=121;s=.7
for j in range(3):
 p.rect(x+j*60*s,y,60*s,120*s,fill='#e1e9ef',stroke='#657d8a',sw=.3)
 for a in range(5):
  for b in range(9):p.rect(x+j*60*s+6+a*7.5,y+7+b*8,1,1,fill='#788d99')
p.dim((x,y),(x+60*s,y),8,'60 ซม.',size=3)
p.dim((x,y+120*s),(x,y),10,'120 ซม.',size=3)
p.text(x+63,y+120*s+10,'ภาพคลี่ผิวฝ้าตามลาด →',3,anchor='middle',bold=True)
p.text(208,79,'ที่มาของจำนวนเผื่องบ',3.8,bold=True)
for yy,t in [(93,'1. พื้นที่ชายคาตามตารางแบบเก่า 43.28 ตร.ม.'),(105,'   ยังไม่ได้ตรวจพื้นที่ซ้ำกับฝ้าลานล่าสุด'),(120,'2. สมมติช่วงยื่นใช้แผ่น 1.00 ม. ต่อกว้าง 0.60 ม.'),(132,'   43.28 ÷ (1.00 × 0.60) → 73 แผ่น'),(147,'3. เพิ่มสำรองแนวลาด / มุม / ข้อมูลไม่ครบ ≈14%'),(159,'   ใช้ตัวประกอบ 1/cos(28.44°) เป็นค่ากันงบ'),(171,'   72.133 × 1.137 → ปัดขึ้น 83 แผ่น'),(186,'4. เผื่อตัดเสียอีก 10% ของ 83 → 9 แผ่น'),(198,'   รวมเผื่องบ 83 + 9 = 92 แผ่น'),(213,'   92 × 58 = 5,336 บาท')]:p.text(208,yy,t,2.8,bold=yy in [132,171,198,213])
p.text(20,239,'ตัวประกอบแนวลาดเป็นเงิน/จำนวนสำรอง ไม่ใช่การยืนยันว่าพื้นที่จริงเท่ากับ 43.28 ÷ cos(28.44°)',2.6)
p.text(20,250,'ถ้าช่วงยื่นเกิน 1.20 ม. หรือมีมุมชนหลังคา ต้องจัดชิ้นต่อและตรวจจำนวนใหม่ก่อนซื้อ',2.8,bold=True)
footer(p,'EV–01 / 01');ev=root/'eaves/OhmHouse_Eaves_Ventilated_Scope_A3.svg';ev.write_text(''.join(p.items)+'</svg>')
q=Page(1,'สรุปวัสดุฝ้า / รวมชายคาเผื่องบ','ภายในเริ่มเต็มแผ่นมุมขวาล่าง + ห้องน้ำกันชื้น + ลาน + ชายคามีรูเอียงตามจั่ว')
q.text(18,44,'รายการแนะนำซื้อ / ชายคาแยกเป็นจำนวนประมาณการ',4,bold=True)
rows=[['ภายใน ไม่รวมห้องน้ำ','ยิปซัมธรรมดา 9 มม.','37','4','41','134','5,494'],['ห้องน้ำ 1–2','ยิปซัมกันชื้น 9 มม.','5','1','6','215','1,290'],['ลานหน้าบ้าน','ไฟเบอร์ซีเมนต์ลายร่อง 6 มม.','15','1','16','329','5,264'],['ชายคารอบบ้าน *','เฌอร่า มีรู 4 มม.','≈83','9','≈92','58','≈5,336'],['รวมเผื่องบ','ชายคายังเป็นประมาณการ','≈140','15','≈155','—','≈17,384']]
q.table(18,52,[65,86,33,32,33,42,85],['โซน','วัสดุ','ใช้/เผื่องบ','เผื่อเสีย','ซื้อ/เผื่องบ','บาท/แผ่น','รวม บาท'],rows,rowh=12,size=2.5)
q.text(18,135,'รวมทุกโซนเผื่องบประมาณ 155 แผ่น = 17,384 บาท',4.3,bold=True)
q.text(18,148,'แยกยอด: 3 โซนมีผังตัด 63 แผ่น / 12,048 บาท + ชายคาประมาณ 92 แผ่น / 5,336 บาท',3)
for yy,t in [(167,'* ชายคา 92 แผ่นเป็นประมาณการเผื่องบ ไม่ใช่ยอดจากผังตัดตรวจวัดครบ'),(179,'อ้างอิงพื้นที่ 43.28 ตร.ม. จากตารางแบบเก่า สมมติช่วงยื่น 1 ม. เพิ่มสำรองแนวลาด/มุมและตัดเสีย'),(191,'ต้องตรวจระยะจริงและหักพื้นที่ทับกับลานก่อนสั่งซื้อจำนวนชายคา'),(209,'ภายในใช้เศษร่วมกันรวม 37 แผ่น ไม่บวก 21 แผ่นห้องนั่งเล่นซ้ำ'),(221,'ห้องน้ำราคา 215 บาทต่อแผ่น • ลาน 4.03 × 8.94 ม. แผ่นที่ 15 ใช้งานจริง'),(233,'ไม่ใช้เศษแผ่นลายร่องของลานทดแทนแผ่นมีรูระบายอากาศ'),(245,'ราคาเฉพาะแผ่น ไม่รวมโครง อุปกรณ์ สี ค่าแรง และขนส่ง')]:q.text(18,yy,t,2.9,bold=yy in [167,191])
footer(q,'CS–01 / 01');cover=root/'Ceiling_Purchase_Summary_A3.svg';cover.write_text(''.join(q.items)+'</svg>')
for src,dst in [(ev,root/'eaves/OhmHouse_Eaves_Ventilated_Scope_A3.pdf'),(cover,root/'Ceiling_Purchase_Summary_A3.pdf')]:subprocess.run(['inkscape',str(src),'--export-type=pdf','--export-filename='+str(dst)],capture_output=True,check=True)
report=json.loads((root/'summary.json').read_text());report['exterior_scope']='porch measured-layout takeoff plus sloped ventilated eaves provisional budget';report['eaves'].update({'source_area_m2':43.28,'source_area_status':'legacy blueprint table, overlap and slope basis unverified','assumed_wall_to_eave_width_m':1.,'base_estimated_boards':73,'contingency_factor':contingency_factor,'contingency_description':'budget reserve for slope/corners/uncertainty, not asserted surface-area conversion','working_estimated_boards':83,'waste_allowance_boards':9,'budget_boards':92,'budget_cost_thb':5336,'quantity_status':'provisional budget only, verify actual widths/corners/porch overlap before ordering','included_in_budget_totals':True,'included_in_known_totals':False});report['totals']['budget_boards_including_provisional_eaves']=155;report['totals']['budget_cost_including_provisional_eaves']=17384
(root/'summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
with (root/'purchase-list.csv').open(encoding='utf-8-sig',newline='') as f:stock=list(csv.DictReader(f));fields=list(stock[0])+['status']
for r in stock:
 r['status']='layout takeoff with spare allowance'
 if r['zone'].startswith('ชายคา'):r.update({'zone':'ชายคารอบบ้าน ประมาณการเผื่องบ','used_boards':'83','spare_boards':'9','purchase_boards':'92','used_cost_thb':'4814','purchase_cost_thb':'5336','status':'PROVISIONAL BUDGET ONLY; verify widths and porch overlap before ordering'})
with (root/'purchase-list.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(stock)
out=fitz.open()
for f in [root/'Ceiling_Purchase_Summary_A3.pdf',root/'interior/OhmHouse_Interior_Ceiling_A3_Plan_and_Cuts.pdf',root/'bathrooms/OhmHouse_Bathroom_Ceiling_A3.pdf',root/'porch/OhmHouse_Porch_Ceiling_A3_Plan_and_Cuts.pdf',root/'eaves/OhmHouse_Eaves_Ventilated_Scope_A3.pdf']:out.insert_pdf(fitz.open(f))
assert len(out)==11
for page in out:assert abs(page.rect.width*25.4/72-420)<.01 and abs(page.rect.height*25.4/72-297)<.01
out.save(root/'OhmHouse_All_Ceilings_Updated.pdf')
fitz.open(root/'Ceiling_Purchase_Summary_A3.pdf')[0].get_pixmap(dpi=110).save(root/'summary-preview.png')
(root/'README.md').write_text('''# Ohm House — รวมวัสดุฝ้าและชายคาเผื่องบ

| โซน | วัสดุ | จำนวนซื้อ/เผื่องบ | บาท/แผ่น | รวมบาท | สถานะ |
|---|---|---:|---:|---:|---|
| ภายใน ไม่รวมห้องน้ำ | ยิปซัมธรรมดา 9 มม. 120×240 | 41 | 134 | 5,494 | ตามผัง 37 + เผื่อ 4 |
| ห้องน้ำ 1–2 | ยิปซัมกันชื้น 9 มม. 120×240 | 6 | 215 | 1,290 | ตามผัง 5 + เผื่อ 1 |
| ลานหน้าบ้าน | ไฟเบอร์ซีเมนต์ลายร่อง 6 มม. 120×240 | 16 | 329 | 5,264 | ตามผัง 15 + เผื่อ 1 |
| ชายคารอบบ้าน | เฌอร่า มีรู เว้นร่อง 3 นิ้ว 4 มม. 60×120 | ประมาณ 92 | 58 | ประมาณ 5,336 | ประมาณการเผื่องบ ยังไม่ใช่ผังตัดครบ |
| รวมเผื่องบ | แยกวัสดุ | ประมาณ 155 | — | ประมาณ 17,384 | รวมส่วนชายคาที่ยังต้องตรวจระยะ |

## ฐานประมาณการชายคา

ผู้ใช้ยืนยันฝ้าเอียงตามแนวจั่ว รุ่นเฌอร่า 60×120 ซม. หนา 4 มม. ราคา 58 บาท/แผ่น พื้นที่ 43.28 ตร.ม. อ้างจากตารางในแบบ construction_drawings.html บน GitHub เดิม ซึ่งยังไม่ยืนยันว่าเป็นพื้นที่ราบหรือผิวจริง และยังไม่ตรวจพื้นที่ซ้ำกับฝ้าลานล่าสุด

เพื่อเผื่องบ: สมมติช่วงยื่น 1 ม. แผ่นวาง 120 ซม. จากผนังออกชายคา / 60 ซม. ตามแนวลาด ใช้ฐาน ceil(43.28/(1×0.6)) = 73 แผ่น เพิ่มตัวประกอบสำรอง 1/cos(28.438°) ≈1.137 สำหรับความไม่แน่นอนของแนวลาด/มุม ไม่ใช่การอ้างว่าเป็นการแปลงพื้นที่จริง ได้ ceil((43.28/0.6)×1.137)=83 แผ่น เผื่อตัดเสีย 10%=9 รวมเผื่องบ92แผ่น/5,336บาท ตัวประกอบมุมอ้างอิง scene-v413.json rseg_lr_symcenter เพื่อใช้เป็นสำรองเชิงงบเท่านั้น

**92 แผ่นไม่ใช่ยอดสั่งซื้อที่ตรวจจากผังตัดชายคาครบ ต้องตรวจระยะช่วงยื่น มุม และพื้นที่ทับลานก่อนสั่งซื้อจริง** หากยื่นเกิน1.20ม.ต้องตรวจวิธีต่อเพิ่ม ไม่ใช้เศษฝ้าลายร่องทดแทนแผ่นมีรู

## ผังยืนยันสามโซนเดิม

ภายใน94.4202ตร.ม. ใช้ยิปซัมธรรมดา37แผ่น/53ชิ้น เริ่มเต็มแผ่นมุมขวาล่างห้องนั่งเล่นและใช้เศษร่วมกับห้องอื่น ไม่บวก21แผ่นทำเฉพาะห้องนั่งเล่นซ้ำ ห้องน้ำ11.76ตร.ม.ใช้5แผ่น/6ชิ้น ราคา215บาทต่อแผ่นตามยืนยัน ลาน4.03×8.94ม.วางขวางใช้15แผ่น/16ชิ้น แผ่น15ใช้จริง ยอดสามโซนรวมเผื่อ63แผ่น/12,048บาท

ราคาเฉพาะแผ่น ไม่รวมโครง อุปกรณ์ สี ค่าแรงและขนส่ง ราคา134บาทยิปซัมธรรมดาสมมติได้โปรทุกแผ่น วัดสุทธิและจัดโครงรองรับตามระบบผู้ผลิตก่อนติดตั้ง

PDFรวม11หน้า พร้อมCSV/JSONและZIPสำรองแหล่งข้อมูลกับสคริปต์ เก็บจำนวนประมาณการแยกจากผังตัดจริงอย่างชัดเจน
''')
(root/'source/include-eaves-budget.py').write_text(Path('/workspace/scratch/include-eaves-budget.py').read_text())
with zipfile.ZipFile(root/'OhmHouse_Ceilings_Backup_2026-10-17.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in root.rglob('*'):
  if not f.is_file() or f.suffix=='.zip' or f.name.startswith('page-') or f.name in ['preview.png','summary-preview.png']:continue
  z.write(f,f.relative_to(root))
print(json.dumps({'eaves_budget_boards':budget,'eaves_budget_cost':cost,'total_budget_boards':total_boards,'total_budget_cost':total_cost,'status':'provisional budget, not final eave cutting takeoff'}))
