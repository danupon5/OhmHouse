from pathlib import Path
import json,csv,subprocess,fitz,zipfile
root=Path('/workspace/shared/downloads/OhmHouse-Ceilings-Final-20261017');(root/'eaves').mkdir(exist_ok=True)
exec(Path('/workspace/scratch/ohm-a3/build.py').read_text().split('p=Page(1,')[0])
p=Page(1,'ฝ้าชายคารอบบ้าน / แผ่นมีรูระบายอากาศ','แผ่นขนาด 120 × 60 ซม. ตามที่ผู้ใช้ระบุ • แยกวัสดุจากฝ้าลาน • หน้านี้เป็นแผนตรวจระยะก่อนสรุปซื้อ')
p.items=[s.replace('A–01 / 06','EV–01 / 01').replace('ชุดแปลนประกอบการวางแผน • อ้างอิง Pascal V384 / ข้อมูล 11 ก.ย. 2026','ขอบเขตเพิ่ม: ฝ้าชายคารอบบ้านแบบมีรู • ไม่หักเศษไฟเบอร์ซีเมนต์ลายร่องมาทดแทนแผ่นมีรู').replace('สร้างชุดเอกสาร 3 ต.ค. 2026','บันทึกขอบเขต 17 ต.ค. 2026').replace('ระยะตามไฟล์แบบ ไม่ใช่ระยะสุทธิหลังฉาบ • ตรวจหน้างานก่อนก่อสร้างหรือสั่งผลิต','ต้องตรวจความกว้างช่วงยื่น แนวราบ/ลาด พื้นที่ซ้ำกับลาน และราคา ก่อนยืนยันจำนวนสั่งซื้อชายคา') for s in p.items]
p.text(20,45,'ขนาดและแนววางแผ่น',4.2,bold=True)
p.text(20,57,'ตัวอย่าง: ด้าน 120 ซม. พาดขวางจากผนังออกสู่ขอบชายคา',3)
p.text(20,67,'ด้าน 60 ซม. เรียงต่อไปตามแนวยาวชายคา • ต้องยืนยันแนวติดตั้งจริง',2.8)
x=30;y=87;s=.7
for j in range(3):
 p.rect(x+j*60*s,y,60*s,120*s,fill='#e1e9ef',stroke='#657d8a',sw=.3)
 for a in range(5):
  for b in range(9):
   cx=x+j*60*s+6+a*7.5;cy=y+7+b*8;p.rect(cx,cy,1,1,fill='#788d99')
p.dim((x,y),(x+60*s,y),8,'60 ซม.',size=3)
p.dim((x,y+120*s),(x,y),10,'120 ซม.',size=3)
p.text(x+63,y+120*s+12,'ต่อไปตามแนวยาวชายคา →',3,anchor='middle',bold=True)
p.text(203,45,'สถานะจำนวนสั่งซื้อ: รอตรวจแนวและระยะ',3.8,bold=True,color='#a35c2d')
for yy,t in [(60,'แบบพิมพ์เขียวเดิมมีรายการชายคา 43.28 ตร.ม.'),(72,'ตัวเลขนี้ยังไม่ใช่พื้นที่สุทธิที่ตรวจไม่ซ้ำกับลานล่าสุด'),(84,'43.28 ÷ 0.72 = 60.11 → 61 แผ่น เป็นเพียงขั้นต่ำตามพื้นที่'),(96,'61 แผ่นไม่ใช่จำนวนสั่งซื้อ เพราะยังไม่รวมเศษตัดและมุม'),(113,'ถ้าช่วงยื่น 1.00 ม. และใช้แผ่นพาดขวาง 1.20 ม.'),(125,'แผ่นหนึ่งปิดได้ประมาณ 0.60 × 1.00 = 0.60 ตร.ม.'),(137,'จึงต้องถอดเป็นช่วง ไม่ใช้พื้นที่แผ่นเต็มหารอย่างเดียว'),(154,'ข้อมูลที่ต้องตรวจเพื่อปิดจำนวนซื้อ:'),(166,'1. ฝ้าราบ หรือฝ้าเอียงตามแนวจั่ว'),(178,'2. ช่วงยื่นจริงจากผนังถึงขอบฝ้าทุกด้าน'),(190,'3. มุมตัด / ช่วงยื่นเกิน 1.20 ม. / พื้นที่ทับลาน'),(202,'4. รุ่น ความหนา และราคาแผ่นมีรู 120 × 60 ซม.')]:p.text(203,yy,t,2.7,bold=yy in [84,96,154])
p.text(20,218,'สรุปการจัดซื้อที่ยืนยันแล้ว (ยังไม่รวมชายคาแผ่นมีรู)',3.6,bold=True)
p.text(20,232,'ยิปซัมธรรมดา 41 + กันชื้น 6 + ไฟเบอร์ซีเมนต์ลาน 16 = 63 แผ่น / 12,048 บาท',3.1,bold=True)
p.text(20,245,'ราคาส่วนชายคายังไม่รวมในยอดนี้ • แผ่นมีรูแยกชนิดจากแผ่นลายร่องของลาน',2.8)
(root/'eaves/OhmHouse_Eaves_Ventilated_Scope_A3.svg').write_text(''.join(p.items)+'</svg>')
subprocess.run(['inkscape',str(root/'eaves/OhmHouse_Eaves_Ventilated_Scope_A3.svg'),'--export-type=pdf','--export-filename='+str(root/'eaves/OhmHouse_Eaves_Ventilated_Scope_A3.pdf')],check=True,capture_output=True)
s=json.loads((root/'summary.json').read_text());s['exterior_scope']='porch confirmed; ventilated eaves added as pending takeoff';s['eaves']={'material':'ventilated soffit board, brand/thickness/price pending','board_size_cm':[120,60],'orientation_provisional':'120 cm wall-to-eave, 60 cm repeated along run','source_blueprint_area_m2_unverified_against_latest_porch':43.28,'area_only_lower_bound_boards_not_purchase_quantity':61,'used_boards':None,'purchase_boards':None,'unit_price_thb':None,'quantity_status':'pending flat/sloped confirmation and actual eave widths; exclude overlap with porch','included_in_known_totals':False};s['totals']['scope']='confirmed interior + bathrooms + porch only, excluding pending ventilated eaves'
(root/'summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2))
with (root/'purchase-list.csv').open('a',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['ชายคารอบบ้าน รอตรวจระยะ','แผ่นมีรูระบายอากาศ',120,60,'43.28 ตามแบบเก่า ยังไม่ตรวจซ้ำลาน','','','','','',''])
# Replace cover with explicit pending fourth zone to avoid claiming a complete buying total.
cover=(root/'Ceiling_Purchase_Summary_A3.svg').read_text().replace('จำนวนที่แนะนำให้ซื้อ รวมเผื่อแตก / ตัดเสีย','จำนวนซื้อที่ยืนยันแล้ว + สถานะชายคาแผ่นมีรู')
cover=cover.replace('แนะนำซื้อทั้งหมด 63 แผ่น = 12,048 บาท','3 โซนที่ยืนยัน: ซื้อ 63 แผ่น = 12,048 บาท')
cover=cover.replace('ขอบเขตภายนอก: ลานหน้าบ้านตามชุดเดิม • ยังไม่ได้ถอดฝ้าชายคารอบบ้านเพิ่ม','โซน 4 ชายคามีรู 120 × 60 ซม.: รอตรวจแนวและระยะ ยังไม่รวมจำนวน / ราคา')
(root/'Ceiling_Purchase_Summary_A3.svg').write_text(cover)
subprocess.run(['inkscape',str(root/'Ceiling_Purchase_Summary_A3.svg'),'--export-type=pdf','--export-filename='+str(root/'Ceiling_Purchase_Summary_A3.pdf')],capture_output=True,check=True)
out=fitz.open()
for f in [root/'Ceiling_Purchase_Summary_A3.pdf',root/'interior/OhmHouse_Interior_Ceiling_A3_Plan_and_Cuts.pdf',root/'bathrooms/OhmHouse_Bathroom_Ceiling_A3.pdf',root/'porch/OhmHouse_Porch_Ceiling_A3_Plan_and_Cuts.pdf',root/'eaves/OhmHouse_Eaves_Ventilated_Scope_A3.pdf']:
 d=fitz.open(f);out.insert_pdf(d)
assert len(out)==11
out.save(root/'OhmHouse_All_Ceilings_Updated.pdf')
with (root/'README.md').open('a') as f:f.write('''\n## เพิ่มชายคารอบบ้านแผ่นมีรูตามคำตอบผู้ใช้\n\nเพิ่มโซนที่ 4 แผ่นมีรูระบายอากาศ 120 × 60 ซม. แนววางเบื้องต้น 120 ซม. พาดจากผนังออกขอบชายคา และ 60 ซม. เรียงตามแนวชายคา ต้องยืนยันฝ้าราบ/ตามลาดและช่วงยื่นจริงก่อนถอดซื้อ แบบเดิมระบุชายคา 43.28 ตร.ม. ซึ่งยังไม่ได้ตรวจพื้นที่ซ้ำกับฝ้าลานล่าสุด ค่า 61 แผ่นจากพื้นที่หารเป็นเพียงขอบล่าง ไม่ใช่ยอดสั่งซื้อ จำนวนใช้ ซื้อ และราคาชายคาจึงเว้นว่าง ไม่ปะปนกับยอด 63 แผ่น / 12,048 บาทของสามโซนที่ยืนยันแล้ว\n\nPDF รวมเพิ่มหน้าขอบเขตชายคาเป็น 11 หน้า ยอดรวมก่อนหน้าหมายถึงเฉพาะสามโซนที่ยืนยัน ไม่ใช่ฝ้าภายนอกทุกส่วน\n''')
(root/'source/add-eaves-scope.py').write_text(Path('/workspace/scratch/add-eaves-scope.py').read_text())
with zipfile.ZipFile(root/'OhmHouse_Ceilings_Backup_2026-10-17.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in root.rglob('*'):
  if not f.is_file() or f.suffix=='.zip' or f.name.startswith('page-') or f.name in ['preview.png','summary-preview.png']:continue
  z.write(f,f.relative_to(root))
print('Added eaves scope, 11 PDF pages. Purchase quantity for eaves deliberately blank pending dimensions.')
