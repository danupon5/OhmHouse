from pathlib import Path
import math,json
exec(Path('/workspace/scratch/ohm-a3/build.py').read_text().split('p=Page(1,')[0])
interior=[r for r in rooms if r['name'] not in ['ลานหน้าบ้าน','น้ำ1','น้ำ2']]
def clip(poly,axis,v,less):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  ia=a[axis]<=v+1e-9 if less else a[axis]>=v-1e-9
  ib=b[axis]<=v+1e-9 if less else b[axis]>=v-1e-9
  if ia:out.append(a)
  if ia!=ib:
   t=(v-a[axis])/(b[axis]-a[axis]);out.append([a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])])
 return out
pieces=[]
for r in interior:
 poly=r['polygon'];x0=min(p[0] for p in poly);z0=min(p[1] for p in poly)
 if r['name']=='นั่งเล่น':x0=11-3*2.4;z0=12.88-math.ceil((12.88-min(v[1] for v in poly))/1.2)*1.2
 for j in range(math.ceil((max(p[1] for p in poly)-z0)/1.2)):
  for i in range(math.ceil((max(p[0] for p in poly)-x0)/2.4)):
   p=poly
   for axis,v,less in [(0,x0+i*2.4,False),(0,x0+(i+1)*2.4,True),(1,z0+j*1.2,False),(1,z0+(j+1)*1.2,True)]:
    if p:p=clip(p,axis,v,less)
   clean=[]
   for v in p:
    if not clean or math.dist(v,clean[-1])>1e-8:clean.append(v)
   if len(clean)>1 and math.dist(clean[0],clean[-1])<1e-8:clean.pop()
   p=clean
   if len(p)<3 or area(p)<1e-8:continue
   minx=min(v[0] for v in p);minz=min(v[1] for v in p);w=max(v[0] for v in p)-minx;h=max(v[1] for v in p)-minz
   pieces.append(dict(room=r['name'],poly=p,w=round(w,6),h=round(h,6),area=area(p),grid=[i,j]))
# Non-rotating guillotine pack: preserve the direction of grooves across rooms.
boards=[]
for p in sorted(pieces,key=lambda p:(-p['w']*p['h'],-p['h'],-p['w'])):
 best=None
 for bi,b in enumerate(boards):
  for ri,r in enumerate(b['free']):
   if p['w']<=r[2]+1e-8 and p['h']<=r[3]+1e-8:
    key=(r[2]*r[3]-p['w']*p['h'],min(r[2]-p['w'],r[3]-p['h']))
    if best is None or key<best[0]:best=(key,bi,ri)
 if best is None:boards.append(dict(free=[(0,0,2.4,1.2)],pieces=[]));best=(None,len(boards)-1,0)
 _,bi,ri=best;b=boards[bi];x,y,w,h=b['free'].pop(ri);pw,ph=p['w'],p['h']
 # choose split keeping the wider useful remainder
 kerf=.003
 if w-pw>h-ph:rr=[(x+pw+kerf,y,w-pw-kerf,h),(x,y+ph+kerf,pw,h-ph-kerf)]
 else:rr=[(x+pw+kerf,y,w-pw-kerf,ph),(x,y+ph+kerf,w,h-ph-kerf)]
 b['free'] += [r for r in rr if r[2]>.003 and r[3]>.003]
 p['board']=bi+1;p['cutpos']=[x,y];b['pieces'].append(p)
for b in boards:
 for i,a in enumerate(b['pieces']):
  assert a['cutpos'][0]+a['w']<=2.4+1e-7 and a['cutpos'][1]+a['h']<=1.2+1e-7
  for c in b['pieces'][:i]:
   ax,ay=a['cutpos'];cx,cy=c['cutpos'];assert ax>=cx+c['w']-1e-8 or cx>=ax+a['w']-1e-8 or ay>=cy+c['h']-1e-8 or cy>=ay+a['h']-1e-8
for r in interior:assert abs(sum(p['area'] for p in pieces if p['room']==r['name'])-area(r['polygon']))<1e-6
for b in boards:
 for i,p in enumerate(b['pieces']):p['label']=f"{p['board']:02}"+(chr(65+i) if len(b['pieces'])>1 else '')
OUT=Path('/workspace/shared/downloads/OhmHouse-Ceilings-Final-20261017/interior')
report={'board_size_m':[2.4,1.2],'material':'ยิปซัมธรรมดาขอบเรียบ','thickness_mm':9,'unit_price':134,'inside_area_m2':sum(area(r['polygon']) for r in interior),'boards':len(boards),'installed_pieces':len(pieces),'price':134*len(boards),'rooms':[{'name':r['name'],'area_m2':area(r['polygon']),'installed_pieces':sum(p['room']==r['name'] for p in pieces),'board_ids':sorted(set(p['board'] for p in pieces if p['room']==r['name']))} for r in interior],'pieces':pieces}
(OUT/'cut-layout.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='pieces'},ensure_ascii=False))
# Vector drawing: exact geometry, quantities and source-board identifiers.
p=Page(1,'ฝ้าภายใน / เริ่มเต็มแผ่นมุมขวาล่าง','ยิปซัม 120 × 240 ซม. หนา 9 มม. • สเกล 1:60 • เลขเดียวกัน = ตัดจากแผ่นเดียวกัน')
p.items=[s.replace('A–01 / 06','IC–01 / 06').replace('ชุดแปลนประกอบการวางแผน • อ้างอิง Pascal V384 / ข้อมูล 11 ก.ย. 2026','ผังถอดวัสดุฝ้า • อ้างอิงขอบห้องที่ตรงกับผังผู้ใช้ส่ง').replace('สร้างชุดเอกสาร 3 ต.ค. 2026','จัดทำ 17 ต.ค. 2026') for s in p.items]
origin=(22,40);k=1000/60;P=lambda v:(origin[0]+v[0]*k,origin[1]+v[1]*k)
for r in rooms:
 p.poly([P(v) for v in r['polygon']],fill='#f3f5f5' if r['name'] in ['ลานหน้าบ้าน','น้ำ1','น้ำ2'] else 'white',stroke='#bdc9cd',sw=.2)
for q in pieces:
 full=abs(q['w']-2.4)<1e-8 and abs(q['h']-1.2)<1e-8 and abs(q['area']-2.88)<1e-8
 q['full']=full
 p.poly([P(v) for v in q['poly']],fill='#d6e9f7' if full else '#dff0df',stroke='#789b9f',sw=.22)
 x,y=P(labelpoint(q['poly']));p.text(x,y+.8,q['label'],2.9,anchor='middle',bold=True,halo=True)
for w in walls:p.line(P(w['start']),P(w['end']),'#344951',w['thickness']*k)
for r in interior:
 x=min(v[0] for v in r['polygon']);z=min(v[1] for v in r['polygon'])
 p.text(*P([x+.13,z+.24]),{'นอน1':'ห้องนอน 1','น้ำ1':'ห้องน้ำ 1','น้ำ2':'ห้องน้ำ 2','นอน2':'ห้องนอน 2','นั่งเล่น':'นั่งเล่น / ครัว','เก็บของ':'เก็บของ'}[r['name']],2.25,bold=True,halo=True)
x,y=P([3.95,8.4]);p.text(x,y,'ลานหน้าบ้าน',3.5,anchor='middle',bold=True);p.text(x,y+6,'ไม่รวมในผังนี้',3,anchor='middle')

for r in rooms:
 if r['name'] in ['น้ำ1','น้ำ2']:
  x,y=P(labelpoint(r['polygon']));p.text(x,y,r['name'],3,anchor='middle',bold=True);p.text(x,y+5,'ไม่รวม',2.8,anchor='middle')
p.text(263,43,'ปริมาณตามผังตัด',4.2,bold=True)
for y,a,b in [(54,'พื้นที่ตามขอบห้องในแบบ','94.42 ตร.ม.'),(65,'แผ่นต้นฉบับที่ต้องใช้','37 แผ่น'),(76,'ชิ้นที่ติดตั้งหลังตัด','53 ชิ้น'),(87,'ราคาแผ่นละ','134 บาท'),(98,'ค่าแผ่นตามผัง','4,958 บาท')]:
 p.text(263,y,a,2.8);p.text(405,y,b,3.1,anchor='end',bold=True)
p.text(263,114,'แนะนำเผื่อแตกเสีย 4 แผ่น',3,bold=True)
p.text(263,122,'ซื้อ 41 แผ่น = 5,494 บาท',3.8,bold=True)
p.text(263,140,'จำนวนชิ้นติดตั้งในแต่ละห้อง',3.4,bold=True)
p.table(263,145,[65,35,42],['ห้อง','พื้นที่ ตร.ม.','ชิ้นติดตั้ง'],[[r['name'],f"{area(r['polygon']):.2f}",str(sum(q['room']==r['name'] for q in pieces))] for r in interior],rowh=6.5,size=2.7)

start=P([8.6,11.68]);p.rect(*start,2.4*k,1.2*k,fill='none',stroke='#b94b30',sw=.65)
p.text(263,191,'ห้องนั่งเล่น: เริ่มเต็มแผ่นมุมขวาล่าง',2.8,bold=True,color='#b94b30')
p.text(263,202,'ชิ้นติดตั้ง ≠ จำนวนแผ่นที่ซื้อ',2.8,bold=True)
p.text(263,210,'เลขเดียวกัน A/B = ใช้เศษจากแผ่นเดียวกัน',2.6)
p.rect(263,217,5,3,fill='#d6e9f7');p.text(271,220,'แผ่นเต็ม',2.8)
p.rect(263,224,5,3,fill='#dff0df');p.text(271,227,'ชิ้นตัด / ใช้เศษร่วมระหว่างห้อง',2.8)
p.text(263,240,'ไม่รวมห้องน้ำ 2 ห้อง ลาน และชายคา',2.7,bold=True)
p.text(263,247,'ราคา 134 บาท/แผ่น เมื่อได้โปรทุกแผ่น',2.6)
p.text(263,254,'ต้องมีโครงรองรับขอบ / ปรับรอยต่อก่อนตัด',2.4)
p.items=[s.replace('ระยะตามไฟล์แบบ ไม่ใช่ระยะสุทธิหลังฉาบ • ตรวจหน้างานก่อนก่อสร้างหรือสั่งผลิต','อ้างอิงขอบห้องตามผังที่ส่ง • วัดสุทธิจริงก่อนตัด • เผื่อใบตัด 3 มม. ในผังใช้เศษ • ไม่รวมโครงและค่าแรง') for s in p.items]
(OUT/'OhmHouse_Interior_Ceiling_Layout_A3.svg').write_text(''.join(p.items)+'</svg>')
cutpaths=[]
for pagei in range(math.ceil(len(boards)/8)):
 pg=Page(pagei+2,'รายการตัดแผ่นฝ้า / ใช้คู่กับหมายเลขในผัง','แผ่น 120 × 240 ซม. • ชิ้น A/B/C เลขเดียวกันมาจากแผ่นเดียวกัน • ขนาดตัวเลขเป็นเซนติเมตร')
 pg.items=[s.replace(f'A–{pagei+2:02} / 06',f'IC–{pagei+2:02} / 06').replace('ชุดแปลนประกอบการวางแผน • อ้างอิง Pascal V384 / ข้อมูล 11 ก.ย. 2026','รายการชิ้นตัดฝ้า • ใช้คู่กับผังแบ่งแผ่นหน้า 1').replace('สร้างชุดเอกสาร 3 ต.ค. 2026','จัดทำ 17 ต.ค. 2026') for s in pg.items]
 for slot,b in enumerate(boards[pagei*8:(pagei+1)*8]):
  bi=pagei*8+slot+1;xx=20+(slot%2)*198;yy=43+(slot//2)*52;scale=26
  pg.text(xx,yy,f'แผ่น {bi:02}',3.2,bold=True)
  pg.rect(xx,yy+3,2.4*scale,1.2*scale,fill='#f3f3f3',stroke='#506570',sw=.2)
  for q in b['pieces']:
   cx,cy=q['cutpos'];pg.rect(xx+cx*scale,yy+3+cy*scale,q['w']*scale,q['h']*scale,fill='#d6e9f7' if q.get('full') else '#dff0df',stroke='#789b9f',sw=.18)
   pg.text(xx+(cx+q['w']/2)*scale,yy+3+(cy+q['h']/2)*scale+.7,q['label'],2.5,anchor='middle',bold=True)
  for j,q in enumerate(b['pieces']):
   pg.text(xx+67,yy+5+j*4.7,f"{q['label']}  {q['w']*100:g} × {q['h']*100:g} ซม. / {q['room']}",2.3)
  pg.text(xx,yy+39,'กรอบชิ้นตัด: ชิ้นรูปตัว L ให้บากตามผังหน้า 1',2.15,color='#63757e')
 path=OUT/f'Cut_Sheet_{pagei+1:02}.svg';path.write_text(''.join(pg.items)+'</svg>');cutpaths.append(str(path))
# Include tabular cutting list for review.
import csv
with (OUT/'ceiling-cut-list.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['board','piece','room','width_cm','height_cm','installed_area_m2'])
 for q in sorted(pieces,key=lambda q:(q['board'],q['label'])):w.writerow([q['board'],q['label'],q['room'],q['w']*100,q['h']*100,q['area']])
