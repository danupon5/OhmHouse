from pathlib import Path
import json,csv
exec(Path('/workspace/scratch/ohm-a3/build.py').read_text().split('p=Page(1,')[0])
OUT=Path('/workspace/shared/downloads/OhmHouse-Ceilings-Updated/bathrooms')
p=Page(1,'ฝ้าห้องน้ำ 1–2 / ยิปซัมกันชื้น','Gyproc กันชื้น ขนาด 120 × 240 ซม. • หนา 9 มม. ตามชุดที่วางแผน • ราคา 215 บาทต่อแผ่น')
p.items=[s.replace('A–01 / 06','BR–01 / 01').replace('ชุดแปลนประกอบการวางแผน • อ้างอิง Pascal V384 / ข้อมูล 11 ก.ย. 2026','ผังถอดวัสดุฝ้าห้องน้ำ • ห้องละ 2.00 × 2.94 ม. • แยกจากฝ้ายิปซัมธรรมดาภายใน').replace('สร้างชุดเอกสาร 3 ต.ค. 2026','อัปเดต 17 ต.ค. 2026').replace('ระยะตามไฟล์แบบ ไม่ใช่ระยะสุทธิหลังฉาบ • ตรวจหน้างานก่อนก่อสร้างหรือสั่งผลิต','วัดสุทธิจริงก่อนตัด / ปรับรอยต่อและโครงตามคู่มือ • ราคายืนยัน 215 บาทต่อแผ่น ไม่ใช่ต่อตารางเมตร') for s in p.items]
scale=35;ox=30;oy=62
parts=[]
for ri in range(2):
 x=ox+ri*83;p.text(x+35,43,f'ห้องน้ำ {ri+1}',4.1,anchor='middle',bold=True)
 for row,h in enumerate([1.2,1.2,.54]):
  y=oy+row*1.2*scale;label=f'B{ri*2+row+1:02}' if row<2 else f'B05{chr(65+ri)}'
  p.rect(x,y,2*scale,h*scale,fill='#cfebe2' if row<2 else '#ffe1bd',stroke='#4b8b7c',sw=.3)
  p.text(x+35,y+h*scale/2-.2,label,4,anchor='middle',bold=True);p.text(x+35,y+h*scale/2+4.6,f'200 × {h*100:g} ซม.',2.8,anchor='middle')
  parts.append(dict(board=ri*2+row+1 if row<2 else 5,piece=label,room=f'ห้องน้ำ {ri+1}',width_cm=200,height_cm=round(h*100,2),x_cm=0,y_cm=0 if row<2 else ri*54.3))
 p.dim((x,oy),(x+70,oy),8,'2.00 ม.',size=3.2)
 p.dim((x,oy+2.94*scale),(x,oy),8,'2.94 ม.',size=3)
 p.text(x+35,oy+2.94*scale+9,'5.88 ตร.ม. / 3 ชิ้นติดตั้ง',2.9,anchor='middle')
p.text(233,43,'ปริมาณและราคา',4.2,bold=True)
for y,a,b in [(57,'พื้นที่ฝ้า 2 ห้อง','11.76 ตร.ม.'),(70,'แผ่นที่ใช้ตามผัง','5 แผ่น'),(83,'ชิ้นติดตั้งหลังตัด','6 ชิ้น'),(96,'ราคาต่อแผ่น','215 บาท'),(109,'ค่าแผ่นตามผัง','1,075 บาท')]:p.text(233,y,a,2.9);p.text(403,y,b,3.6,anchor='end',bold=True)
p.text(233,125,'ซื้อเผื่อ 1 แผ่น: 6 แผ่น = 1,290 บาท',3.4,bold=True)
p.text(233,137,'ยืนยันราคาเป็นต่อแผ่น ไม่ใช่ต่อตารางเมตร',2.7)
p.text(233,150,'B01–B04: ตัด 200 × 120 ซม. แผ่นละ 1 ชิ้น',2.8)
p.text(233,160,'B05: ตัด 200 × 54 ซม. จำนวน 2 ชิ้น',2.8,bold=True)
p.text(233,170,'B05A / B05B ใช้แผ่นเดียวกันร่วม 2 ห้อง',2.8)
# Cutting illustrations use real dimensions and leave 3 mm kerf between parts.
p.text(25,192,'ตัด B01–B04 เหมือนกัน',3.2,bold=True)
s=.31;x=25;y=199;p.rect(x,y,240*s,120*s,fill='#eeeeee',stroke='#506570',sw=.2);p.rect(x,y,200*s,120*s,fill='#cfebe2',stroke='#4b8b7c',sw=.2)
p.text(x+100*s,y+60*s,'200 × 120',2.7,anchor='middle',bold=True);p.text(x+220*s,y+60*s,'เศษ',2.2,anchor='middle')
p.text(25,244,'เหลือเศษกว้างประมาณ 40 ซม. ต่อแผ่น',2.5)
p.text(130,192,'ตัด B05: 2 ห้องใช้ร่วมกัน',3.2,bold=True)
x=130;y=199;p.rect(x,y,240*s,120*s,fill='#eeeeee',stroke='#506570',sw=.2)
for i in range(2):
 p.rect(x,y+i*54.3*s,200*s,54*s,fill='#ffe1bd',stroke='#a37745',sw=.2);p.text(x+100*s,y+(i*54.3+27)*s,f'B05{chr(65+i)} 200 × 54',2.6,anchor='middle',bold=True)
p.text(130,244,'เผื่อใบตัด 3 มม. / เศษจริงปรับตามแนวตัด',2.4)
p.text(233,195,'หมายเลขวัสดุแยกจากชุดภายใน',3.0,bold=True)
p.text(233,205,'B01–B05 = ยิปซัมกันชื้นเท่านั้น',2.8)
p.text(233,215,'ไม่ใช้เศษยิปซัมธรรมดามาปิดห้องน้ำ',2.8)
p.text(233,229,'เลือกความหนา/ระบบโครงให้ตรงคู่มือผู้ผลิต',2.7)
p.text(233,239,'ผังเพื่อถอดวัสดุ ไม่ใช่แบบโครงคร่าว',2.7)
p.text(233,249,'ราคาเฉพาะแผ่น ไม่รวมค่าแรงและอุปกรณ์',2.7)
(OUT/'OhmHouse_Bathroom_Ceiling_Layout_A3.svg').write_text(''.join(p.items)+'</svg>')
assert abs(sum(t['width_cm']*t['height_cm']/10000 for t in parts)-11.76)<1e-8
assert len(set(t['board'] for t in parts))==5
report={'material':'Gyproc moisture resistant gypsum','thickness_mm_assumed':9,'board_size_cm':[120,240],'rooms':2,'room_size_m':[2,2.94],'installed_area_m2':11.76,'boards':5,'installed_pieces':6,'price_unit':'THB per sheet, confirmed by user','unit_price':215,'price':1075,'recommended_boards_including_one_spare':6,'recommended_price':1290,'parts':parts}
(OUT/'bathroom-cut-layout.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
with (OUT/'bathroom-cut-list.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(parts[0]));w.writeheader();w.writerows(parts)
print(json.dumps({k:v for k,v in report.items() if k!='parts'},ensure_ascii=False))
