from pathlib import Path
import json,csv
exec(Path('/workspace/scratch/ohm-a3/build.py').read_text().split('p=Page(1,')[0])
OUT=Path('/workspace/shared/downloads/OhmHouse-Ceilings-Updated/porch')
p=Page(1,'ฝ้าลานหน้าบ้าน / วางขวาง','ไฟเบอร์ซีเมนต์ลายร่อง 120 × 240 ซม. หนา 6 มม. • ขนาดหลังร่นขอบ 4.03 × 8.94 ม. • สเกลผัง 1:50')
def footer(pg,sheet):
 pg.items=[s.replace(f'A–{pg.num:02} / 06',f'PC–{sheet:02} / 02').replace('ชุดแปลนประกอบการวางแผน • อ้างอิง Pascal V384 / ข้อมูล 11 ก.ย. 2026','ผังถอดวัสดุฝ้าลาน • ความยาวเดิม 9.04 ม. ร่นขอบรวม 0.10 ม.').replace('สร้างชุดเอกสาร 3 ต.ค. 2026','อัปเดต 17 ต.ค. 2026').replace('ระยะตามไฟล์แบบ ไม่ใช่ระยะสุทธิหลังฉาบ • ตรวจหน้างานก่อนก่อสร้างหรือสั่งผลิต','ขนาดชิ้นตัดต้องปรับรอยต่อ / ใบตัด • ทุกขอบและรอยต่อต้องมีโครงรองรับ • ราคาเฉพาะแผ่น ไม่รวมค่าแรง') for s in pg.items]
k=20;ox=58;oy=58;P=lambda v:(ox+v[0]*k,oy+v[1]*k)
parts=[]
for row in range(7):
 for col,(x,w) in enumerate([(0,2.4),(2.4,1.63)]):
  b=row*2+col+1;y=row*1.2
  p.rect(*P([x,y]),w*k,1.2*k,fill='#d6e9f7' if col==0 else '#ffe1bd',stroke='#789b9f',sw=.25)
  cx,cy=P([x+w/2,y+.6]);p.text(cx,cy-.5,f'{b:02}',4,anchor='middle',bold=True);p.text(cx,cy+5,f'{w*100:g} × 120 ซม.',2.7,anchor='middle')
  parts.append(dict(board=b,piece=f'{b:02}',width_cm=w*100,height_cm=120,x_m=x,y_m=y))
for x,w,label in [(0,2.4,'15A'),(2.4,1.63,'15B')]:
 p.rect(*P([x,8.4]),w*k,.54*k,fill='#dff0df',stroke='#789b9f',sw=.25)
 cx,cy=P([x+w/2,8.67]);p.text(cx,cy,label,3.2,anchor='middle',bold=True);p.text(cx,cy+4,f'{w*100:g} × 54 ซม.',2.4,anchor='middle')
 parts.append(dict(board=15,piece=label,width_cm=w*100,height_cm=54,x_m=x,y_m=8.4))
p.dim(P([0,0]),P([4.03,0]),12,'กว้าง 4.03 ม.',size=3.5)
p.dim(P([0,0]),P([2.4,0]),5,'2.40 ม.',size=2.8);p.dim(P([2.4,0]),P([4.03,0]),5,'1.63 ม.',size=2.8)
p.dim(P([0,8.94]),P([0,0]),12,'ยาว 8.94 ม.',size=3.5)
p.dim(P([4.03,0]),P([4.03,8.4]),10,'7 แถว × 1.20 = 8.40 ม.',size=2.8)
p.dim(P([4.03,8.4]),P([4.03,8.94]),10,'0.54 ม.',size=2.6)
p.text(98,245,'ด้านยาว 240 ซม. วางขวาง →',3,anchor='middle',bold=True)
x=192
p.text(x,43,'15 แผ่น = 4,935 บาท',5,bold=True)
p.text(x,53,'ราคาแผ่นละ 329 บาท • ใช้จริงทั้ง 15 แผ่น',3)
p.text(x,63,'9.04 − 0.10 = 8.94 ม.',3.4,bold=True)
p.text(x,71,'8.94 − 8.40 = แถวท้าย 0.54 ม.',3.1)
p.text(x,86,'กลุ่มแผ่น 01–14',3.8,bold=True)
p.text(x,96,'เลขคี่ 01,03,05,07,09,11,13: ใช้เต็ม 240 × 120 ซม.',2.9)
p.text(x,104,'เลขคู่ 02,04,06,08,10,12,14: ตัดเหลือ 163 × 120 ซม.',2.9)
p.text(x,112,'เหลือเศษประมาณ 77 × 120 ซม. จำนวน 7 ชิ้น',3,bold=True)
p.text(x,120,'เศษนี้เก็บใช้กับฝ้าชายคาได้ • หักรอยใบตัดจากขนาดเศษ',2.6)
p.text(x,136,'วิธีตัดแผ่นที่ 15',3.8,bold=True)
s=.6;xx=x;yy=143
p.rect(xx,yy,240*s,120*s,fill='#f2f2f2',stroke='#506570',sw=.2)
p.rect(xx,yy,240*s,54*s,fill='#dff0df',stroke='#789b9f',sw=.2)
p.rect(xx,yy+54*s,163*s,54*s,fill='#dff0df',stroke='#789b9f',sw=.2)
p.text(xx+120*s,yy+27*s,'15A  240 × 54 ซม.',3.2,anchor='middle',bold=True)
p.text(xx+81.5*s,yy+81*s,'15B  163 × 54 ซม.',3.2,anchor='middle',bold=True)
p.text(xx+201.5*s,yy+81*s,'เศษ 77 × 54',2.5,anchor='middle')
p.text(xx+120*s,yy+115*s,'เศษแถบล่างประมาณ 240 × 12 ซม.',2.2,anchor='middle')
p.text(x,225,'ชิ้นท้าย 15A / 15B มีรอยต่อเดียวตรงกับแนวแถวบน',2.8)
p.text(x,235,'หากเผื่อแตกเสียเพิ่ม 1 แผ่น: 16 แผ่น = 5,264 บาท',2.9,bold=True)
p.text(x,245,'หักความยาวรวม 10 ซม. ไม่ใช่ร่นด้านละ 10 ซม.',2.7)
footer(p,1);(OUT/'OhmHouse_Porch_Ceiling_Layout_A3.svg').write_text(''.join(p.items)+'</svg>')
q=Page(2,'รายการตัดและสรุปวัสดุ / ลานหน้าบ้าน','อ้างอิงตำแหน่งแผ่นในผังหน้า 1 • ไม่รวมฝ้าภายในบ้าน • ขนาดชิ้นตัดเป็นเซนติเมตร')
q.text(18,43,'รายการตัดแผ่น 120 × 240 ซม. หนา 6 มม.',4,bold=True)
rows=[]
for row in range(7):
 a=row*2+1;b=a+1;rows.append([f'{a:02}','240 × 120','1','เต็มแผ่น'])
 rows.append([f'{b:02}','163 × 120','1','เหลือเศษ ≈77 × 120'])
rows.append(['15','240 × 54 + 163 × 54','2','ตัดปิดท้าย 2 ชิ้นจากแผ่นเดียว'])
q.table(18,48,[22,58,20,97],['แผ่น','ชิ้นตัด ซม.','ชิ้น','หมายเหตุ'],rows,rowh=9,size=2.8)
q.text(232,47,'วัสดุลานหน้าบ้าน',4,bold=True)
for yy,t in [(59,'ไฟเบอร์ซีเมนต์ลายร่อง หนา 6 มม.'),(69,'ใช้จริง 15 แผ่น • 16 ชิ้นติดตั้ง'),(79,'พื้นที่ติดตั้ง 4.03 × 8.94 = 36.0282 ตร.ม.'),(89,'ราคา 15 × 329 = 4,935 บาท'),(105,'เศษจากแผ่นคู่ 7 ชิ้น'),(115,'รวมก่อนหักใบตัดประมาณ 6.47 ตร.ม.'),(125,'ขนาดเศษจริงจะเล็กลงตามความกว้างใบตัด'),(141,'เศษฝ้าลานนี้เป็นไฟเบอร์ซีเมนต์ 6 มม.'),(151,'วัสดุภายในเป็นยิปซัม 9 มม. คนละวัสดุ'),(161,'ไม่รวมเศษข้ามวัสดุในการคำนวณ'),(181,'หน้างานต้องตรวจระยะโครงและขอบแผ่น'),(191,'ชิ้น 15A/B ต้องปรับเผื่อรอยต่อก่อนตัด'),(211,'ซื้อเผื่อเพิ่มเป็น 16 แผ่น = 5,264 บาท')]:q.text(232,yy,t,2.8,bold=yy in [69,89,105,211])
footer(q,2);(OUT/'Porch_Cut_List_A3.svg').write_text(''.join(q.items)+'</svg>')
assert abs(sum(t['width_cm']*t['height_cm']/10000 for t in parts)-4.03*8.94)<1e-8
report={'area_m2':4.03*8.94,'size_m':[4.03,8.94],'material':'ไฟเบอร์ซีเมนต์ลายร่อง','thickness_mm':6,'boards':15,'unit_price':329,'price':4935,'installed_pieces':16,'spare_option_boards':16,'spare_option_price':5264,'cut_dimensions_before_joint_adjustment':True,'parts':parts}
(OUT/'porch-cut-layout.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
with (OUT/'porch-cut-list.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(parts[0]));w.writeheader();w.writerows(parts)
print(json.dumps({k:v for k,v in report.items() if k!='parts'},ensure_ascii=False))
