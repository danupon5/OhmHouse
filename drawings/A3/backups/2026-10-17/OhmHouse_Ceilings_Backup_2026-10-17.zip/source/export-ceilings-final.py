from pathlib import Path
import subprocess,fitz,json,zipfile,csv
root=Path('/workspace/shared/downloads/OhmHouse-Ceilings-Final-20261017');inside=root/'interior'
svgs=[inside/'OhmHouse_Interior_Ceiling_Layout_A3.svg']+sorted(inside.glob('Cut_Sheet_*.svg'));dout=fitz.open()
for i,s in enumerate(svgs):
 pdf=inside/f'page-{i}.pdf';subprocess.run(['inkscape',str(s),'--export-type=pdf','--export-filename='+str(pdf)],capture_output=True,check=True);d=fitz.open(pdf);assert len(d)==1 and not d[0].get_images();dout.insert_pdf(d)
 if i==0:d[0].get_pixmap(dpi=300).save(inside/'OhmHouse_Interior_Ceiling_Layout_300dpi.png');d[0].get_pixmap(dpi=100).save(inside/'preview.png')
dout.save(root/'interior'/'OhmHouse_Interior_Ceiling_A3_Plan_and_Cuts.pdf')
i=json.loads((inside/'cut-layout.json').read_text());b=json.loads((root/'bathrooms/bathroom-cut-layout.json').read_text());p=json.loads((root/'porch/porch-cut-layout.json').read_text())
assert i['boards']==37 and i['price']==4958 and abs(i['inside_area_m2']-94.4202)<1e-7
assert b['boards']==5 and b['unit_price']==215 and p['boards']==15
stock=[dict(zone='ภายใน ไม่รวมห้องน้ำ',material='ยิปซัมธรรมดา 9 มม.',width_cm=120,length_cm=240,installed_area_m2=94.4202,used_boards=37,spare_boards=4,purchase_boards=41,unit_price_thb=134,used_cost_thb=4958,purchase_cost_thb=5494),dict(zone='ห้องน้ำ 1–2',material='ยิปซัมกันชื้น 9 มม.',width_cm=120,length_cm=240,installed_area_m2=11.76,used_boards=5,spare_boards=1,purchase_boards=6,unit_price_thb=215,used_cost_thb=1075,purchase_cost_thb=1290),dict(zone='ภายนอก ลานหน้าบ้าน',material='ไฟเบอร์ซีเมนต์ลายร่อง 6 มม.',width_cm=120,length_cm=240,installed_area_m2=36.0282,used_boards=15,spare_boards=1,purchase_boards=16,unit_price_thb=329,used_cost_thb=4935,purchase_cost_thb=5264)]
totals={k:sum(r[k] for r in stock) for k in ['used_boards','spare_boards','purchase_boards','used_cost_thb','purchase_cost_thb']}
assert totals==dict(used_boards=57,spare_boards=6,purchase_boards=63,used_cost_thb=10968,purchase_cost_thb=12048)
summary={'date':'2026-10-17','revision':'living-room full board at bottom-right; interior offcuts shared','exterior_scope':'porch 4.03x8.94m; no additional whole-house eave takeoff','stock':stock,'totals':totals,'regular_gypsum_price_assumption':'134 THB per board for every purchased board','bathroom_price_confirmation':'215 THB PER BOARD confirmed by user','interior':{k:v for k,v in i.items() if k!='pieces'},'bathrooms':{k:v for k,v in b.items() if k!='parts'},'porch':{k:v for k,v in p.items() if k!='parts'}}
(root/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
with (root/'purchase-list.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(stock[0]));w.writeheader();w.writerows(stock)
exec(Path('/workspace/scratch/ohm-a3/build.py').read_text().split('p=Page(1,')[0])
q=Page(1,'สรุปจำนวนซื้อฝ้า / ชุดรวมล่าสุด','ภายในเริ่มเต็มแผ่นมุมขวาล่าง + ห้องน้ำกันชื้น + ภายนอกลานหน้าบ้าน • ขนาดแผ่นทุกชนิด 120 × 240 ซม.')
q.items=[s.replace('A–01 / 06','CS–01 / 01').replace('ชุดแปลนประกอบการวางแผน • อ้างอิง Pascal V384 / ข้อมูล 11 ก.ย. 2026','สรุปวัสดุฝ้าตามผังล่าสุด • ใช้เศษร่วมเฉพาะวัสดุชนิดเดียวกัน').replace('สร้างชุดเอกสาร 3 ต.ค. 2026','สำรองชุดล่าสุด 17 ต.ค. 2026').replace('ระยะตามไฟล์แบบ ไม่ใช่ระยะสุทธิหลังฉาบ • ตรวจหน้างานก่อนก่อสร้างหรือสั่งผลิต','เฉพาะค่าแผ่น ไม่รวมโครง อุปกรณ์ สี ค่าแรง และขนส่ง • ยิปซัมธรรมดาคิดโปร 134 บาททุกแผ่น') for s in q.items]
q.text(18,45,'จำนวนที่แนะนำให้ซื้อ รวมเผื่อแตก / ตัดเสีย',4.2,bold=True)
q.table(18,53,[65,86,33,32,33,42,85],['โซน','ชนิดแผ่น','ใช้ตามผัง','เผื่อ','ซื้อรวม','บาท/แผ่น','เงินซื้อรวม บาท'],[[s['zone'],s['material'],str(s['used_boards']),str(s['spare_boards']),str(s['purchase_boards']),str(s['unit_price_thb']),f"{s['purchase_cost_thb']:,}"] for s in stock]+[['รวม','แยกวัสดุทั้ง 3 ชนิด','57','6','63','—','12,048']],rowh=12,size=2.6)
q.text(18,127,'แนะนำซื้อทั้งหมด 63 แผ่น = 12,048 บาท',4.6,bold=True)
q.text(18,140,'ถ้าซื้อพอดีตามผัง ไม่เผื่อเสีย: 57 แผ่น = 10,968 บาท',3.4)
q.text(18,157,'ผังที่ใช้คำนวณในชุดนี้',3.6,bold=True)
for y,t in [(169,'ภายใน 94.42 ตร.ม.: ห้องนั่งเล่นเริ่มเต็มแผ่นที่มุมขวาล่าง ไล่ซ้ายและขึ้นด้านบน'),(180,'จำนวนภายใน 37 แผ่น ใช้เศษร่วมกับห้องนอนและเก็บของ ไม่บวก 21 แผ่นห้องนั่งเล่นซ้ำ'),(191,'ห้องน้ำรวม 11.76 ตร.ม.: B01–B04 แยกห้อง / B05 ตัดชิ้นท้ายใช้ร่วมสองห้อง'),(202,'ลานหน้าบ้าน 4.03 × 8.94 ม.: วางด้าน 240 ซม. ขวาง / แผ่น 15 ตัดปิดท้ายสูง 54 ซม.'),(220,'ขอบเขตภายนอก: ลานหน้าบ้านตามชุดเดิม • ยังไม่ได้ถอดฝ้าชายคารอบบ้านเพิ่ม'),(231,'ยิปซัมกันชื้นราคา 215 บาทต่อแผ่นตามยืนยัน • หนา 9 มม. ตรวจฉลากสินค้าก่อนซื้อ'),(242,'ต้องวัดสุทธิจริง ปรับรอยต่อ และจัดโครงรองรับขอบตามคู่มือผู้ผลิตก่อนติดตั้ง')]:q.text(18,y,t,2.9,bold=y in [180,220])
(root/'Ceiling_Purchase_Summary_A3.svg').write_text(''.join(q.items)+'</svg>')
subprocess.run(['inkscape',str(root/'Ceiling_Purchase_Summary_A3.svg'),'--export-type=pdf','--export-filename='+str(root/'Ceiling_Purchase_Summary_A3.pdf')],check=True,capture_output=True)
out=fitz.open()
for f in [root/'Ceiling_Purchase_Summary_A3.pdf',root/'interior'/'OhmHouse_Interior_Ceiling_A3_Plan_and_Cuts.pdf',root/'bathrooms/OhmHouse_Bathroom_Ceiling_A3.pdf',root/'porch/OhmHouse_Porch_Ceiling_A3_Plan_and_Cuts.pdf']:
 d=fitz.open(f)
 for page in d:
  assert abs(page.rect.width*25.4/72-420)<.01 and abs(page.rect.height*25.4/72-297)<.01 and not page.get_images()
 out.insert_pdf(d)
assert len(out)==10
out.save(root/'OhmHouse_All_Ceilings_Updated.pdf')
fitz.open(root/'Ceiling_Purchase_Summary_A3.pdf')[0].get_pixmap(dpi=110).save(root/'summary-preview.png')
(root/'README.md').write_text('''# สรุปฝ้า Ohm House — สำรองชุดล่าสุด 17 ต.ค. 2026

ใช้ผังห้องนั่งเล่นเริ่มเต็มแผ่นที่มุมขวาล่าง ไล่ซ้ายและขึ้นด้านบน รวมการใช้เศษกับห้องอื่นเป็นยิปซัมธรรมดาภายใน 37 แผ่น ไม่บวกยอดทำเฉพาะห้องนั่งเล่น 21 แผ่นซ้ำ

| โซน | วัสดุ 120 × 240 ซม. | ใช้ตามผัง | เผื่อ | ซื้อแนะนำ | บาท/แผ่น | เงินซื้อแนะนำ |
|---|---|---:|---:|---:|---:|---:|
| ภายใน ไม่รวมห้องน้ำ | ยิปซัมธรรมดา 9 มม. | 37 | 4 | 41 | 134 | 5,494 |
| ห้องน้ำ 1–2 | ยิปซัมกันชื้น วางแผน 9 มม. | 5 | 1 | 6 | 215 | 1,290 |
| ภายนอก ลานหน้าบ้าน | ไฟเบอร์ซีเมนต์ลายร่อง 6 มม. | 15 | 1 | 16 | 329 | 5,264 |
| รวม | แยกวัสดุสามชนิด | 57 | 6 | 63 | — | 12,048 |

ซื้อพอดีตามผัง 57 แผ่น = 10,968 บาท ก่อนเผื่อเสีย ราคานี้เฉพาะแผ่น ไม่รวมโครง อุปกรณ์ สี ค่าแรง และขนส่ง ยิปซัมธรรมดาคิดราคาโปร 134 บาททุกแผ่น กันชื้น 215 บาทต่อแผ่นตามยืนยันของผู้ใช้

## ขอบเขตและวิธีอ่าน

- พื้นที่ภายในไม่รวมห้องน้ำ 94.4202 ตร.ม. ใช้ยิปซัมธรรมดา 37 แผ่น / 53 ชิ้นติดตั้ง
- ห้องน้ำห้องละ 2.00 × 2.94 ม. รวม 11.76 ตร.ม. ใช้ 5 แผ่น / 6 ชิ้น หมายเลข B01–B05 แยกจากชุดภายใน
- ภายนอกในชุดนี้หมายถึงลานหน้าบ้าน 4.03 × 8.94 ม. หลังร่นความยาวรวม 10 ซม. จาก 9.04 ม. ใช้ 15 แผ่น / 16 ชิ้น แผ่นที่ 15 ใช้งานจริง ไม่ใช่แผ่นเผื่อ
- ยังไม่ได้ถอดฝ้าชายคารอบบ้านเพิ่ม จึงไม่อ้างว่าเป็นปริมาณฝ้าภายนอกทุกพื้นที่
- เลขเดียวกันพร้อม A/B/C คือชิ้นตัดจากแผ่นต้นฉบับเดียวกัน ไม่ใช่แผ่นซื้อเพิ่ม นำเศษร่วมเฉพาะวัสดุชนิดเดียวกัน
- ผังเป็นการถอดวัสดุตามขอบห้อง ไม่ใช่แบบติดตั้งโครง วัดสุทธิจริง ปรับรอยต่อ เผื่อใบตัด และจัดโครงรองรับตามระบบผู้ผลิต ความหนารุ่นกันชื้นให้ตรวจฉลากก่อนซื้อ

## ไฟล์

PDF รวม 10 หน้า: หน้าสรุปซื้อ + ภายใน 6 หน้า + ห้องน้ำ 1 หน้า + ลาน 2 หน้า
ZIP สำรองรวม PDF แต่ละโซน, ภาพผัง, SVG, รายการตัด CSV/JSON และสคริปต์สร้างแบบ เพื่อให้ตรวจสอบและแก้ไขต่อได้
''')
# Self-contained source backup; no dependency on a conversation-only image.
source=root/'source';source.mkdir(exist_ok=True)
for script in ['interior-ceiling-final.py','porch-ceiling-updated.py','bathroom-ceiling-updated.py','export-ceilings-final.py']:
 shutil_src=Path('/workspace/scratch')/script
 if shutil_src.exists(): (source/script).write_text(shutil_src.read_text())
(source/'original-a3-helpers.py').write_text(Path('/workspace/scratch/ohm-a3/build.py').read_text().split('p=Page(1,')[0])
(source/'scene.json').write_text(Path('/workspace/scratch/ohm-a3/scene.json').read_text())
with zipfile.ZipFile(root/'OhmHouse_Ceilings_Backup_2026-10-17.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in root.rglob('*'):
  if not f.is_file() or f.suffix=='.zip' or f.name.startswith('page-') or f.name in ['preview.png','summary-preview.png']:continue
  z.write(f,f.relative_to(root))
print(json.dumps(totals));print('PDF pages',len(out))
