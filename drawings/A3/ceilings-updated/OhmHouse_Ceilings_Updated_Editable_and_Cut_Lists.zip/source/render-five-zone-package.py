from pathlib import Path
import math,json,csv,subprocess,fitz,zipfile,shutil
exec(Path('/workspace/scratch/ohm-a3/build.py').read_text().split('p=Page(1,')[0])
ROOT=Path('/workspace/shared/downloads/OhmHouse-All-Ceilings-Crosswise-84THB');old=Path('/workspace/shared/downloads/OhmHouse-Ceilings-Final-20261017')
for folder in ['interior','bathrooms','porch']:shutil.copytree(old/folder,ROOT/folder,dirs_exist_ok=True)
A=json.loads((ROOT/'eaves-100cm.json').read_text());B=json.loads((ROOT/'eaves-70cm.json').read_text());S=json.loads((ROOT/'smartboard-layout.json').read_text())
assert (A['board_count'],B['board_count'],S['board_count'])==(80,76,21)
# Prove excluded porch and both plain Smartboard pockets contain no ventilation pieces.
for op in [A,B]:
 for p in op['pieces']:
  for rect in [op['porch_exclusion'],[11,0,12.79,5],[11,9.38,12.79,12.88]]:
   q=p['poly']
   for axis,v,ls in [(0,rect[0],False),(0,rect[2],True),(1,rect[1],False),(1,rect[3],True)]:
    if q:
     out=[]
     for a,b in zip(q,q[1:]+q[:1]):
      ia=a[axis]<=v+1e-8 if ls else a[axis]>=v-1e-8;ib=b[axis]<=v+1e-8 if ls else b[axis]>=v-1e-8
      if ia:out.append(a)
      if ia!=ib:
       t=(v-a[axis])/(b[axis]-a[axis]);out.append([a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])])
     q=out
   assert len(q)<3 or area(q)<1e-7
COL={'inside':'#cde6f7','bath':'#c5ebc8','porch':'#ffdab3','vent':'#b5ece8','smart':'#fff0a1'}
def footer(p,code):
 p.items=[s.replace(f'A–{p.num:02} / 06',code).replace('ชุดแปลนประกอบการวางแผน • อ้างอิง Pascal V384 / ข้อมูล 11 ก.ย. 2026','ชุดสรุปฝ้า 5 โซน • แยกฝ้ามีรูออกจาก Smartboard เรียบตามที่ผู้ใช้ยืนยัน').replace('สร้างชุดเอกสาร 3 ต.ค. 2026','อัปเดต 17 ต.ค. 2026').replace('ระยะตามไฟล์แบบ ไม่ใช่ระยะสุทธิหลังฉาบ • ตรวจหน้างานก่อนก่อสร้างหรือสั่งผลิต','ชายคาเป็นผังเปรียบเทียบ ไม่ใช่ผลวัด GLB ล่าสุด • ตรวจขอบหลังคาจริงและโครงรับก่อนสั่งซื้อ') for s in p.items]
# Purchase summary includes two alternatives, never adds both alternatives.
p=Page(1,'สรุปซื้อฝ้าครบ 5 โซน / 2 ทางเลือกชายคา','ภายในเริ่มเต็มแผ่นมุมขวาล่าง • ห้องน้ำกันชื้น • ลาน • ชายคามีรูแถบแคบ • Smartboard ซักล้างและส่วนเว้า')
p.text(18,44,'จำนวนแผ่นรวมเผื่อเสีย',4,bold=True)
rows=[['ภายใน ไม่รวมห้องน้ำ','ยิปซัมธรรมดา 9 มม. / 120×240','37','4','41','134','5,494'],['ห้องน้ำ 1–2','ยิปซัมกันชื้น / 120×240','5','1','6','215','1,290'],['ลานหน้าบ้าน','ไฟเบอร์ซีเมนต์ลายร่อง 6 มม.','15','1','16','329','5,264'],['ชายคามีรู A / B','เฌอร่า 4 มม. + ตะแกรง / 60×120','80 / 76','8 / 8','88 / 84','84','7,392 / 7,056'],['Smartboard เรียบ','ซักล้าง + ส่วนเว้า / 60×120','21','3','24','รอราคา','24 × ราคา/แผ่น']]
p.table(18,52,[62,100,34,30,33,31,86],['ส่วนงาน','วัสดุ / ขนาด ซม.','ใช้ตามผัง','เผื่อ','ซื้อรวม','บาท/แผ่น','รวมบาท'],rows,rowh=11,size=2.55)
p.text(18,132,'A ชายคากว้าง 1 เมตร: รวมวางแผนซื้อ 175 แผ่น',4,bold=True)
p.text(18,143,'ราคาที่ทราบ 19,440 บาท + Smartboard 24 แผ่น × ราคา/แผ่น',3.3)
p.text(18,158,'B ชายคากว้าง 70 ซม.: รวมวางแผนซื้อ 171 แผ่น',4,bold=True)
p.text(18,169,'ราคาที่ทราบ 19,104 บาท + Smartboard 24 แผ่น × ราคา/แผ่น',3.3)
for y,t in [(187,'เลือก A หรือ B เพียงชุดเดียว • ไม่บวกจำนวนชายคาสองแบบเข้าด้วยกัน'),(198,'ฝ้าภายนอก: ลาน 16 + Smartboard 24 + ชายคา A88 / B84 = A128 / B124 แผ่น'),(211,'Smartboard ยังไม่กำหนดความหนา/ราคา: จำนวนถอดจากแผ่น 60 × 120 ซม. ที่ยืนยันแล้ว'),(223,'แถบชายคาอยู่ริมขอบหลังคาตรง ไม่ขยายตามผนังเว้า และไม่คิดทับเพิงลาน'),(235,'จำนวนชายคาและ Smartboard เป็นผังวางแผนตามสมมติฐานระบุในชุดนี้ ต้องตรวจหน้างาน'),(247,'ยอดเดิม 155 แผ่น / 17,384 บาท และผังชายคาที่ตามแนวผนัง ถูกแทนด้วยชุด 5 โซนนี้')]:p.text(18,y,t,2.8,bold=y in [187,223,247])
footer(p,'CS–01 / 01');(ROOT/'01_Purchase_Summary.svg').write_text(''.join(p.items)+'</svg>')

def draw_plan(p,op,P,labels=True,boardnums=False):
 def poly(points,fill,stroke='#6b8998',sw=.2):p.poly([P(v) for v in points],fill=fill,stroke=stroke,sw=sw)
 for q in op['pieces']:poly(q['poly'],COL['vent'],sw=.16)
 # Porch frame is not a ventilated eave; ceiling itself shown with old installed trim.
 poly([[2.5,5],[5.5,5],[5.5,12.88],[2.5,12.88]],COL['porch'])
 for r in rooms:
  if r['name']=='ลานหน้าบ้าน':continue
  poly(r['polygon'],COL['bath'] if r['name'].startswith('น้ำ') else COL['inside'])
 for rect,name in [([11,0,12.79,5],'ซักล้าง'),([11,9.38,12.79,12.88],'ส่วนเว้า')]:
  x,z,xx,zz=rect;poly([[x,z],[xx,z],[xx,zz],[x,zz]],COL['smart'])
  if labels:
   cx,cy=P([(x+xx)/2,(z+zz)/2]);p.text(cx,cy,name,2.5,anchor='middle',bold=True);p.text(cx,cy+4,'Smartboard',2.1,anchor='middle')
 # Actual house wall boundaries stay distinct from roof outline.
 poly(op['house'],'none','#344951',.6)
 for w in walls:
  if (w['start'][0]>=11 and w['end'][0]>=11) or w['code'] in ['WL10','WL11','WL12','WL13','WL17','WL18']:p.line(P(w['start']),P(w['end']),'#344951',.45)
 poly(op['roof_outer'],'none','#147a9b',.5)
 if labels:
  for pos,name in [([1.6,2.2],'ห้องนอน 1'),([4.5,1.4],'น้ำ 1'),([6.5,1.4],'น้ำ 2'),([9.2,2.2],'ห้องนอน 2'),([8,8.7],'นั่งเล่น / ครัว'),([11.85,8.35],'เก็บของ'),([4,8.9],'ลานหน้าบ้าน')]:
   x,y=P(pos);p.text(x,y,name,2.65,anchor='middle',bold=True,halo=True)
 if boardnums:
  for q in op['pieces']:
   if q['projected_area']<.05:continue
   c=[sum(v[k] for v in q['poly'])/len(q['poly']) for k in [0,1]];x,y=P(c);p.text(x,y+.45,q['label'],1.35,anchor='middle')

p=Page(1,'ภาพรวมแบ่งวัสดุ / 5 โซนที่ยืนยัน','แถบชายคามีรูคงความกว้างริมขอบหลังคา • ซักล้างและส่วนเว้าขวาล่างใช้ Smartboard เรียบแยก')
P=lambda v:(29+v[0]*14.4,51+v[1]*14.4)
draw_plan(p,B,P)
p.text(250,43,'วัสดุในแต่ละโซน',4,bold=True)
for j,(key,title,detail) in enumerate([('inside','ภายในบ้าน','ยิปซัมธรรมดา 9 มม.'),('bath','ห้องน้ำ 1–2','ยิปซัมกันชื้น'),('porch','ลานหน้าบ้าน','ไฟเบอร์ซีเมนต์ลายร่อง 6 มม.'),('vent','แถบชายคารอบนอก','เฌอร่า มีรู 4 มม.'),('smart','ซักล้าง / ส่วนเว้าขวาล่าง','Smartboard เรียบ 60 × 120 ซม.')]):
 y=59+j*26;p.rect(250,y-5,7,7,fill=COL[key],stroke='#54778a',sw=.2);p.text(262,y,title,3.1,bold=True);p.text(262,y+7,detail,2.8)
for y,t in [(200,'สีเหลืองไม่รวมในจำนวนแผ่นฝ้ามีรู'),(211,'กรอบเพิงลานถูกหักจากชายคา ไม่คิดทับซ้อน'),(225,'ภาพนี้แสดงแถบ 70 ซม. เพื่ออธิบายโซน'),(236,'ยังเลือกได้ระหว่าง A 1 เมตร / B 70 ซม.'),(247,'ภาพแบ่งโซน ไม่ใช้แทนแบบวัดขอบหลังคาจริง')]:p.text(250,y,t,2.7,bold=y==200)
footer(p,'Z–01 / 01');(ROOT/'02_Zoning_Overview.svg').write_text(''.join(p.items)+'</svg>')
# Comparison drawing, corrected outer edge follows the expanded covered envelope, not storage walls.
p=Page(1,'ชายคาแนวขวาง / เทียบ 1 เมตร กับ 70 ซม.','ด้าน 120 ซม. จากผนังออกขอบชายคา • มีตะแกรงกันแมลง 84 บาท/แผ่น • ไม่รวมเพิงลานและ Smartboard')
for j,op in enumerate([A,B]):
 ox=26+j*204;k=11.1;P=lambda v:(ox+v[0]*k,67+v[1]*k)
 p.text(ox,42,f"{'A' if j==0 else 'B'} แถบชายคา {op['overhang_m']*100:g} ซม.",3.8,bold=True)
 draw_plan(p,op,P,labels=True,boardnums=False)
 y=229;p.text(ox,y,f"ใช้ {op['board_count']} แผ่น + เผื่อ {op['spares']} = {op['purchase_count']} แผ่น",3.4,bold=True)
 p.text(ox,y+10,f"{op['purchase_count']} × 84 = {op['purchase_cost']:,} บาท",3.7,bold=True)
 p.text(ox,y+20,f"ผิวประมาณ {op['surface_area']:.2f} ตร.ม. / ไม่รวม Smartboard",2.6)
footer(p,'EV–01 / 01');(ROOT/'03_Eaves_Comparison.svg').write_text(''.join(p.items)+'</svg>')

# Numbered crosswise layouts for review.
eave_maps=[]
for op in [B,A]:
 cm=round(op['overhang_m']*100)
 p=Page(1,f'ผังเลขแผ่นชายคาแนวขวาง / {cm} ซม.','ด้านยาว 120 ซม. พาดผนังถึงขอบชายคา • แผ่นมีรูพร้อมตะแกรงกันแมลง • เลขเดียวกันใช้เศษร่วมกัน')
 P=lambda v:(35+v[0]*14,57+v[1]*14)
 draw_plan(p,op,P,labels=True,boardnums=True)
 for y,t in [(50,f"ใช้ตามผัง {op['board_count']} แผ่น"),(65,f"เผื่อ {op['spares']} แผ่น"),(80,f"รวมซื้อ {op['purchase_count']} แผ่น"),(95,f"84 บาท/แผ่น = {op['purchase_cost']:,} บาท"),(118,'เลขเดียวกัน A/B = ตัดจากแผ่นเดียวกัน'),(134,'สีเหลือง Smartboard ไม่นับรวมชายคา'),(150,'สีส้ม ลานหน้า ไม่นับรวมชายคา'),(175,'ฝ้าเอียงตามจั่ว คิดความยาวลาดแล้ว'),(192,'120 ซม. คือแนวตั้งฉากกับขอบชายคา'),(210,'ตรวจระยะจริง โครง และจุดยึดก่อนติดตั้ง'),(228,'จำนวนเป็นผังประมาณ ไม่ใช่ผลสำรวจหน้างาน')]:
  p.text(258,y,t,2.8,bold=y in [80,95])
 footer(p,f'EC–{cm}');path=ROOT/f'05_Crosswise_Numbered_{cm}cm.svg';path.write_text(''.join(p.items)+'</svg>');eave_maps.append(path)

# Plain-board layout: rectangle sizes approximate the net ceiling areas documented in v413 README.
p=Page(1,'ฝ้าเรียบ Smartboard / ซักล้างและส่วนเว้า','แผ่น 60 × 120 ซม. ตามที่ยืนยัน • ความหนาและราคายังไม่เลือก • หมายเลข S แยกจากฝ้ามีรู')
for j,z in enumerate(S['rooms']):
 k=28;ox=30+j*86;oy=57;P=lambda v:(ox+(v[0]-z['x'])*k,oy+(v[1]-z['z'])*k)
 p.text(ox+z['w']*k/2,43,z['name'],3.6,anchor='middle',bold=True)
 for q in S['pieces']:
  if q['zone']!=z['name']:continue
  p.poly([P(v) for v in q['poly']],fill=COL['smart'],stroke='#9b8d54',sw=.25)
  c=[z['x']+q['x']+q['w']/2,z['z']+q['y']+q['h']/2];x,y=P(c);p.text(x,y+.6,'S'+q['label'],2.5,anchor='middle',bold=True)
 p.dim(P([z['x'],z['z']]),P([z['x']+z['w'],z['z']]),6,'≈1.79 ม.',size=2.8)
 p.text(ox,oy+z['h']*k+10,f"กรอบประมาณ {z['w']:.2f} × {z['h']:.2f} ม.",2.8)
p.text(220,43,'Smartboard เรียบสองโซน',4,bold=True)
for y,t in [(58,'พื้นที่ตามเอกสารโมเดล 8.65 + 6.05 = 14.70 ตร.ม.'),(71,'ใช้ 21 แผ่น + เผื่อ 3 แผ่น = ซื้อวางแผน 24 แผ่น'),(84,'ขนาดแผ่น 60 × 120 ซม. • ไม่ปะปนเศษกับแผ่นมีรู'),(97,'ยังไม่รวมราคา เพราะยังไม่เลือกรุ่น/ความหนา'),(115,'ที่มาระยะในผังตัดนี้:'),(127,'ใช้กรอบ 1.79 × 4.83 และ 1.79 × 3.38 ม.'),(139,'เพื่อแทนพื้นที่สุทธิ 8.65 / 6.05 ตร.ม. ใน README v413'),(151,'เป็นกรอบประมาณจากพื้นที่ ไม่ใช่ผลวัด GLB รายขอบ'),(169,'เลข S เดียวกัน A/B/C = ตัดจากแผ่นเดียวกัน'),(181,'จัดแนวรอยต่อหลีกเลี่ยงชิ้นขอบแคบ 3 ซม.'),(193,'ชิ้นเล็กสุดตามแนวแถวในผังนี้ไม่น้อยกว่า 18 ซม.'),(211,'ตรวจระยะสุทธิและโครงก่อนตัดจริง'),(223,'ใช้ Smartboard ที่ผู้ผลิตรับรองกับงานฝ้าภายนอก')]:p.text(220,y,t,2.8,bold=y in [71,97,151])
footer(p,'SB–01 / 04');(ROOT/'04_Smartboard_Layout.svg').write_text(''.join(p.items)+'</svg>')
smart_svgs=[]
for pi in range(3):
 p=Page(pi+1,'รายการตัด Smartboard เรียบ / แผ่น 60 × 120 ซม.','หมายเลข S อ้างอิงเฉพาะ Smartboard เรียบทั้งสองโซน • ขนาดชิ้นเป็นเซนติเมตร')
 for slot,bi in enumerate(range(pi*8+1,min(pi*8+9,S['board_count']+1))):
  x=20+(slot%2)*198;y=43+(slot//2)*52;k=52;qq=[q for q in S['pieces'] if q['board']==bi]
  p.text(x,y,f'S{bi:02}',3.3,bold=True);p.rect(x,y+3,1.2*k,.6*k,fill='#f0f0f0',stroke='#6c7f8c',sw=.2)
  for j,q in enumerate(qq):
   cx,cy=q['cutpos'];p.rect(x+cx*k,y+3+cy*k,q['cut_w']*k,q['cut_h']*k,fill=COL['smart'],stroke='#9b8d54',sw=.18)
   p.text(x+(cx+q['cut_w']/2)*k,y+3+(cy+q['cut_h']/2)*k+.7,'S'+q['label'],2.3,anchor='middle',bold=True)
   p.text(x+67,y+5+j*4.7,f"S{q['label']} {q['w']*100:g} × {q['h']*100:g} / {q['zone']}",2.3)
 footer(p,f'SB–{pi+2:02} / 04');path=ROOT/f'Smartboard_Cuts_{pi+1:02}.svg';path.write_text(''.join(p.items)+'</svg>');smart_svgs.append(path)
# Purchase CSV and detailed cut lists, distinguishing the alternatives and assumptions.
stock=[dict(zone='ภายใน',material='ยิปซัมธรรมดา9มม120x240',used=37,spare=4,buy=41,unit_price=134,total=5494,status='existing cutting plan'),dict(zone='ห้องน้ำ',material='ยิปซัมกันชื้น120x240',used=5,spare=1,buy=6,unit_price=215,total=1290,status='existing cutting plan'),dict(zone='ลาน',material='ไฟเบอร์ซีเมนต์ลายร่อง6มม120x240',used=15,spare=1,buy=16,unit_price=329,total=5264,status='existing cutting plan'),dict(zone='ชายคาA1ม',material='เฌอร่ามีรู+ตะแกรง4มม60x120',used=80,spare=8,buy=88,unit_price=84,total=7392,status='hypothetical corrected band model; verify roof fits'),dict(zone='ชายคาB70ซม',material='เฌอร่ามีรู+ตะแกรง4มม60x120',used=76,spare=8,buy=84,unit_price=84,total=7056,status='alternative toA; do not add both'),dict(zone='Smartboard2จุด',material='เรียบ60x120 ความหนารอเลือก',used=21,spare=3,buy=24,unit_price='',total='',status='rectangular approximation of documented net areas; price pending')]
with (ROOT/'purchase-list.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(stock[0]));w.writeheader();w.writerows(stock)
for name,pieces in [('eaves-A-100cm',A['pieces']),('eaves-B-70cm',B['pieces']),('smartboard',S['pieces'])]:
 with (ROOT/f'{name}-cut-list.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f);w.writerow(['board','piece','cut_width_cm','cut_height_cm','source_width_cm','source_height_cm'])
  for q in sorted(pieces,key=lambda q:(q['board'],q['label'])):w.writerow([q['board'],q['label'],q['cut_w']*100,q['cut_h']*100,q['w']*100,q['h']*100])
report=dict(revision='5 zones, CROSSWISE 120cm wall-to-fascia, insect screen vent boards 84THB each, straight right edge',material_stock=stock,option_A=dict(purchase_boards=175,known_cost_excluding_smartboard=19440,smartboard_boards=24,exterior_boards=128),option_B=dict(purchase_boards=171,known_cost_excluding_smartboard=19104,smartboard_boards=24,exterior_boards=124),smartboard_price=None,deprecated_counts=['155 boards/17384 THB','83 vs77 ventilated boards following stepped house walls'],assumptions=['Eave model uses straight covered envelope including Smartboard pockets, not stepped room walls','Band A1m orB0.7m measured as hypothetical projection from covered envelope','Existing roof must accommodate selected band width; no roof alteration work priced','Porch exclusion uses4.03x9.04m ceiling reference frame, not measured shed roof edge','Smartboard dimensions1.79x4.83 and1.79x3.38 approximate source areas8.65 and6.05m2, not surveyed dimensions','No Smartboard price or thickness invented'])
(ROOT/'summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
# Export exact vector diagrams and combine all zones.
rendered={}
for svg in [ROOT/'01_Purchase_Summary.svg',ROOT/'02_Zoning_Overview.svg',ROOT/'03_Eaves_Comparison.svg',ROOT/'04_Smartboard_Layout.svg',*smart_svgs,*eave_maps]:
 pdf=svg.with_suffix('.pdf');subprocess.run(['inkscape',str(svg),'--export-type=pdf','--export-filename='+str(pdf)],check=True,capture_output=True);rendered[svg.name]=pdf
 if svg in eave_maps or svg.name in ['01_Purchase_Summary.svg','02_Zoning_Overview.svg','03_Eaves_Comparison.svg','04_Smartboard_Layout.svg']:
  d=fitz.open(pdf);d[0].get_pixmap(dpi=200).save(svg.with_suffix('.png'));d[0].get_pixmap(dpi=90).save(svg.with_name(svg.stem+'-preview.png'))
combined=fitz.open()
order=[rendered['01_Purchase_Summary.svg'],rendered['02_Zoning_Overview.svg'],ROOT/'interior/OhmHouse_Interior_Ceiling_A3_Plan_and_Cuts.pdf',ROOT/'bathrooms/OhmHouse_Bathroom_Ceiling_A3.pdf',ROOT/'porch/OhmHouse_Porch_Ceiling_A3_Plan_and_Cuts.pdf',rendered['04_Smartboard_Layout.svg'],*[rendered[p.name] for p in smart_svgs],rendered['03_Eaves_Comparison.svg'],*[rendered[q.name] for q in eave_maps]]
for f in order:
 d=fitz.open(f)
 for page in d:assert abs(page.rect.width*25.4/72-420)<.01 and abs(page.rect.height*25.4/72-297)<.01
 combined.insert_pdf(d)
assert len(combined)==18;combined.save(ROOT/'OhmHouse_All_Ceilings_5_Zones_Updated.pdf')
(ROOT/'README.md').write_text('''# ชุดรวมฝ้า 5 โซนที่ยืนยัน — 17 ตุลาคม 2026

ชายคาเลือกแนวขวาง ด้านยาว 120 ซม. พาดจากผนังถึงขอบชายคา รุ่นมีตะแกรงกันแมลง ราคา 84 บาท/แผ่น ตามที่ผู้ใช้ยืนยัน

## จำนวนวางแผนซื้อ รวมเผื่อเสีย

| โซน | ใช้ตามผัง | เผื่อ | ซื้อรวม | บาท/แผ่น | รวมบาท |
|---|---:|---:|---:|---:|---:|
| ยิปซัมธรรมดา 9 มม. 120×240 ภายใน | 37 | 4 | 41 | 134 | 5,494 |
| ยิปซัมกันชื้น 120×240 ห้องน้ำ | 5 | 1 | 6 | 215 | 1,290 |
| ไฟเบอร์ซีเมนต์ลายร่อง 6 มม.120×240 ลาน | 15 | 1 | 16 | 329 | 5,264 |
| เฌอร่ามีรู+ตะแกรง4มม60×120 ชายคา A1ม. | 80 | 8 | 88 | 84 | 7,392 |
| หรือ เฌอร่ามีรู+ตะแกรง4มม60×120 ชายคา B70ซม. | 76 | 8 | 84 | 84 | 7,056 |
| Smartboardเรียบ60×120 ซักล้าง+ส่วนเว้า | 21 | 3 | 24 | ยังไม่มีราคา | ยังไม่รวม |

เลือกชายคา A หรือ B เพียงชุดเดียว:
- A รวมทุกโซน175แผ่น ราคาที่ทราบ19,440บาท บวกSmartboard24แผ่น×ราคา/แผ่น
- B รวมทุกโซน171แผ่น ราคาที่ทราบ19,104บาท บวกSmartboard24แผ่น×ราคา/แผ่น
- เฉพาะภายนอก (ลาน+ชายคา+Smartboard): A128แผ่น หรือB124แผ่น

## การแก้ไขโซน

ขอบหลังคาขวาตรงต่อเนื่อง แถบฝ้ามีรูคงความกว้างที่ริมขอบ พื้นที่ว่างเหนือห้องเก็บของ(ซักล้าง)และใต้ห้องเก็บของ(ส่วนเว้า)เป็นSmartboardเรียบ ไม่รวมในฝ้ามีรู หักกรอบเพิงลานออกทั้งสองแบบ ภายในใช้ผังเริ่มเต็มแผ่นมุมขวาล่างห้องนั่งเล่น และใช้เศษกับห้องอื่น ไม่บวกยอดทำเฉพาะห้องนั่งเล่น21แผ่นซ้ำ

## ฐานคำนวณและข้อจำกัด

1. ชายคาเป็นแบบสมมติเปรียบเทียบ A1ม./B0.7ม. รอบกรอบฝ้าคลุมบ้านรวมSmartboard ที่แก้ให้ด้านขวาตรง ใช้มุม25°ปีกห้องนอนและ28.438°/17.045°ห้องนั่งเล่น แยกชิ้นที่สันจั่วและแบ่งมุม หักกรอบเพิง4.03×9.04ม.จากฝ้าลานเดิม พิกัดกรอบตัด[1.47,5,5.5,14.04]เมตร ไม่ใช่ผลวัดขอบหลังคาGLBล่าสุด ต้องตรวจว่าความกว้างที่เลือกอยู่ใต้หลังคาเดิมได้ ไม่มีราคางานขยายโครงหลังคา
2. ทุกชิ้นฝ้ามีรูตรวจแล้วไม่ทับกรอบเพิงหรือโซนSmartboard รูปหลังคา/ชิ้นตัดเป็นแบบวางแผน ไม่ใช่shop drawingอนุมัติติดตั้ง
3. Smartboardผู้ใช้เลือก60×120ซม. ความหนาและราคายังไม่ยืนยัน พื้นที่สุทธิ8.65+6.05=14.70ตร.ม.อ้างREADME-v413.mdบนGitHub ผังตัดใช้กรอบประมาณ1.79×4.83และ1.79×3.38ม.ให้พื้นที่14.6959ตร.ม. ยังไม่ใช่ระยะสำรวจรายขอบ แผ่นเรียบหมุนตัดใช้เศษร่วมได้ หลีกเลี่ยงขอบ3ซม. ชิ้นตามแนวแถวเล็กสุดในผัง18ซม.
4. การใช้เศษเผื่อใบตัด3มม. ตรวจชิ้นอยู่ในแผ่นและไม่ซ้อนกัน กริดเพื่อถอดวัสดุ ไม่ใช่ผังโครง ต้องวัดสุทธิและจัดโครงรองรับทุกขอบตามคู่มือ
5. ราคายิปซัมธรรมดา134บาทสมมติได้โปรทุกแผ่น ราคาเฉพาะแผ่น ไม่รวมโครง อุปกรณ์ สี ค่าแรงและขนส่ง

## ยอดเดิมที่เลิกใช้

ชุดนี้แทนยอด155แผ่น/17,384บาทและผังชายคา83/77แผ่นที่เดินตามผนังเว้า เพราะโซนเหล่านั้นยังไม่ได้แยกSmartboardและแก้แนวขอบหลังคาตรง ไม่ควรใช้ยอดเก่าสั่งซื้อ

## ไฟล์สำรอง

PDFรวม18หน้า พร้อมภาพผัง รายการซื้อCSV รายการตัดCSV/JSONแยกวัสดุ SVGและสคริปต์สร้างแบบ เลือกทางเลือกชายคาก่อนสั่งซื้อและยืนยันรุ่นSmartboardเพื่อรวมราคาให้ครบ
''')
source=ROOT/'source';source.mkdir(exist_ok=True)
for fn in ['eaves-approved-zones.py','smartboard-approved-zones.py','render-five-zone-package.py']:(source/fn).write_text((Path('/workspace/scratch')/fn).read_text())
for fn in ['original-a3-helpers.py','scene.json']:
 src=old/'source'/fn
 if src.exists():shutil.copy2(src,source/fn)
with zipfile.ZipFile(ROOT/'OhmHouse_Ceilings_5_Zones_Backup.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in ROOT.rglob('*'):
  if not f.is_file() or f.suffix=='.zip' or '-preview' in f.name or f.name.startswith('page-') or f.name=='preview.png':continue
  z.write(f,f.relative_to(ROOT))
print('Verified 18-page A3 PDF and5zone backup')
print(json.dumps(report['option_A']));print(json.dumps(report['option_B']))
print('ZIP bytes',(ROOT/'OhmHouse_Ceilings_5_Zones_Backup.zip').stat().st_size)
