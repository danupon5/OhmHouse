from pathlib import Path
import math,json
exec(Path('/workspace/scratch/ohm-a3/build.py').read_text().split('p=Page(1,')[0])
root=Path('/workspace/shared/downloads/OhmHouse-Ceilings-Five-Zones-20261017')
# Corrected roof/ceiling envelope: includes the plain-soffit pockets,
# so the right edge stays straight. Ventilated board never fills those pockets.
envelope=[[0,0],[12.79,0],[12.79,12.88],[5.5,12.88],[5.5,5],[0,5]]
house=[[0,0],[11,0],[11,5],[12.79,5],[12.79,9.38],[11,9.38],[11,12.88],[5.5,12.88],[5.5,5],[0,5]]
shed=[1.47,5,5.5,14.04]
smart=[dict(name='ซักล้าง',x=11,z=0,w=1.79,h=4.83,source_area=8.65),dict(name='ส่วนเว้าขวาล่าง',x=11,z=9.5,w=1.79,h=3.38,source_area=6.05)]
def clip(poly,axis,v,less):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  ia=a[axis]<=v+1e-9 if less else a[axis]>=v-1e-9;ib=b[axis]<=v+1e-9 if less else b[axis]>=v-1e-9
  if ia:out.append(a)
  if ia!=ib:
   t=(v-a[axis])/(b[axis]-a[axis]);out.append([a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])])
 clean=[]
 for a in out:
  if not clean or math.dist(a,clean[-1])>1e-8:clean.append(a)
 if len(clean)>1 and math.dist(clean[0],clean[-1])<1e-8:clean.pop()
 return clean

def outside_rect(p):
 result=[];remaining=p
 for axis,v,less in [(0,shed[0],False),(0,shed[2],True),(1,shed[1],False),(1,shed[3],True)]:
  if not remaining:break
  q=clip(remaining,axis,v,not less)
  if len(q)>=3 and area(q)>1e-8:result.append(q)
  remaining=clip(remaining,axis,v,less)
 return result

def cross(a,b):return a[0]*b[1]-a[1]*b[0]
def intersect(p,u,q,v):
 t=cross([q[0]-p[0],q[1]-p[1]],v)/cross(u,v)
 return [p[0]+t*u[0],p[1]+t*u[1]]

def pack(pieces,W,H,rotate=False):
 boards=[]
 for p in sorted(pieces,key=lambda p:(-p['w']*p['h'],-max(p['w'],p['h']))):
  best=None
  for bi,b in enumerate(boards):
   for ri,r in enumerate(b['free']):
    for rot in ([False,True] if rotate else [False]):
     pw,ph=(p['h'],p['w']) if rot else (p['w'],p['h'])
     if pw<=r[2]+1e-8 and ph<=r[3]+1e-8:
      score=(r[2]*r[3]-pw*ph,min(r[2]-pw,r[3]-ph))
      if best is None or score<best[0]:best=(score,bi,ri,rot)
  if best is None:
   rot=False
   if not(p['w']<=W+1e-8 and p['h']<=H+1e-8):
    assert rotate and p['h']<=W+1e-8 and p['w']<=H+1e-8;rot=True
   boards.append(dict(free=[(0,0,W,H)],pieces=[]));best=(None,len(boards)-1,0,rot)
  _,bi,ri,rot=best;b=boards[bi];x,y,w,h=b['free'].pop(ri);pw,ph=(p['h'],p['w']) if rot else(p['w'],p['h']);k=.003
  rr=[(x+pw+k,y,w-pw-k,h),(x,y+ph+k,pw,h-ph-k)] if w-pw>h-ph else [(x+pw+k,y,w-pw-k,ph),(x,y+ph+k,w,h-ph-k)]
  b['free'] += [r for r in rr if r[2]>.003 and r[3]>.003];p.update(board=bi+1,cutpos=[x,y],cut_w=pw,cut_h=ph,rotated=rot);b['pieces'].append(p)
 for bi,b in enumerate(boards):
  for i,p in enumerate(b['pieces']):
   p['label']=f'{bi+1:02}'+(chr(65+i) if len(b['pieces'])>1 else '')
   assert p['cutpos'][0]+p['cut_w']<=W+1e-7 and p['cutpos'][1]+p['cut_h']<=H+1e-7
   for q in b['pieces'][:i]:
    x,y=p['cutpos'];xx,yy=q['cutpos'];assert x>=xx+q['cut_w']-1e-7 or xx>=x+p['cut_w']-1e-7 or y>=yy+q['cut_h']-1e-7 or yy>=y+p['cut_h']-1e-7
 return boards

def generate(d):
 sides=[]
 for i,a in enumerate(envelope):
  b=envelope[(i+1)%len(envelope)];L=math.dist(a,b);u=[(b[0]-a[0])/L,(b[1]-a[1])/L];sides.append(dict(a=a,b=b,L=L,u=u,n=[u[1],-u[0]]))
 outer=[]
 for i,s in enumerate(sides):
  prev=sides[i-1];outer.append(intersect([prev['a'][k]+d*prev['n'][k] for k in [0,1]],prev['u'],[s['a'][k]+d*s['n'][k] for k in [0,1]],s['u']))
 fac=lambda pitch:1/math.cos(math.radians(pitch))
 pieces=[]
 for i,s in enumerate(sides):
  a,u,n=s['a'],s['u'],s['n'];q=[a,s['b'],outer[(i+1)%len(envelope)],outer[i]];faces=[]
  if i==5:
   for less in [True,False]:
    f=clip(q,1,2.5,less)
    if len(f)>=3 and area(f)>1e-8:faces.append((f,fac(25),1))
  elif i==1:
   # Upper bedroom wing end and lower living-room eave use their own slope axes.
   for less in [True,False]:
    f=clip(q,1,5,less)
    if len(f)>=3 and area(f)>1e-8:faces.append((f,fac(25) if less else 1,1 if less else fac(17.0446630076526)))
  elif i==2:
   for less,pitch in [(True,28.438356311680547),(False,17.0446630076526)]:
    f=clip(q,0,8.19,less)
    if len(f)>=3 and area(f)>1e-8:faces.append((f,fac(pitch),1))
  else:faces=[(q,1,fac(28.438356311680547 if i==3 else 25))]
  local=lambda p:[sum((p[k]-a[k])*u[k] for k in [0,1]),sum((p[k]-a[k])*n[k] for k in [0,1])]
  world=lambda p:[a[k]+u[k]*p[0]+n[k]*p[1] for k in [0,1]]
  for f,along,depth in faces:
   coords=[local(v) for v in f];lo=min(v[0] for v in coords);hi=max(v[0] for v in coords)
   for j in range(math.ceil((hi-lo)*along/.6-1e-8)):
    aa=lo+j*.6/along;bb=min(hi,aa+.6/along);q=clip(clip(coords,0,aa,False),0,bb,True)
    if len(q)<3 or area(q)<1e-8:continue
    for frag in outside_rect([world(v) for v in q]):
     loc=[local(v) for v in frag];w=(max(v[1] for v in loc)-min(v[1] for v in loc))*depth;h=(max(v[0] for v in loc)-min(v[0] for v in loc))*along
     assert w<=1.2+1e-7 and h<=.6+1e-7
     pieces.append(dict(side=i+1,poly=frag,w=round(w,6),h=round(h,6),projected_area=area(frag),surface_area=area(frag)*along*depth))
 for p in pieces:
  assert max(v[0] for v in p['poly'])<=12.79+d+1e-7
  # All ventilation lies outside the covered/Smartboard envelope.
  assert not inside([sum(v[0] for v in p['poly'])/len(p['poly']),sum(v[1] for v in p['poly'])/len(p['poly'])],envelope)
 b=pack(pieces,1.2,.6);count=len(b);spare=math.ceil(count*.1)
 return dict(overhang_m=d,board_count=count,spares=spare,purchase_count=count+spare,unit_price=58,purchase_cost=(count+spare)*58,pieces=pieces,projected_area=sum(p['projected_area'] for p in pieces),surface_area=sum(p['surface_area'] for p in pieces),house=house,covered_envelope=envelope,roof_outer=outer,porch_exclusion=shed,plain_smartboard_zones=smart,status='hypothetical uniform band around corrected straight-edge ceiling envelope; verify existing roof edge before installation')
options=[generate(1.),generate(.7)]
for o in options:
 (root/f"eaves-{int(o['overhang_m']*100)}cm.json").write_text(json.dumps(o,ensure_ascii=False,indent=2))
 print(json.dumps({k:v for k,v in o.items() if k not in ['pieces','roof_outer','house','covered_envelope','plain_smartboard_zones']},ensure_ascii=False))
