from pathlib import Path
import math,json,copy
s=Path('/workspace/scratch/eaves-approved-zones.py').read_text().split('options=[generate')[0]
exec(s)
# Search seam phases to avoid the 3cm strip from a naive grid on the 4.83m zone.
best=None
for o1 in [v*.03 for v in range(20)]:
 for o2 in [v*.03 for v in range(20)]:
  pieces=[];valid=True
  for z,off in zip(smart,[o1,o2]):
   for j in range(math.ceil((z['h']+off)/.6-1e-8)):
    y1=max(0,j*.6-off);y2=min(z['h'],(j+1)*.6-off);h=y2-y1
    if h<1e-7:continue
    if h<.149999:valid=False;break
    for x,w in [(0,1.2),(1.2,.59)]:pieces.append(dict(zone=z['name'],w=w,h=round(h,6),x=x,y=y1,poly=[[z['x']+x,z['z']+y1],[z['x']+x+w,z['z']+y1],[z['x']+x+w,z['z']+y2],[z['x']+x,z['z']+y2]]))
   if not valid:break
  if not valid:continue
  boards=pack(pieces,1.2,.6,rotate=True);score=(len(boards),len(pieces),-min(p['h'] for p in pieces))
  if best is None or score<best[0]:best=(score,pieces,boards,[o1,o2])
score,pieces,boards,offsets=best;qty=len(boards);spare=math.ceil(qty*.1)
for zone in smart:
 actual=sum(p['w']*p['h'] for p in pieces if p['zone']==zone['name'])
 assert abs(actual-zone['w']*zone['h'])<1e-7
report=dict(board_size_cm=[60,120],material='Smartboard plain exterior ceiling; thickness/price not selected',board_count=qty,spares=spare,purchase_count=qty+spare,unit_price=None,source_area_m2=14.70,rectangular_planning_area_m2=sum(z['w']*z['h'] for z in smart),rooms=smart,seam_offsets_m=offsets,pieces=pieces,status='cutting layout uses 1.79x4.83 and1.79x3.38m rectangular approximations of 8.65 and6.05m2 source terraces; verify clear dimensions')
(root/'smartboard-layout.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='pieces'},ensure_ascii=False))
