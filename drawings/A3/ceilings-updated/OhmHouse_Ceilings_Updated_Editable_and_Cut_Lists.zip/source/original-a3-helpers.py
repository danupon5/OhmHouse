import json, math, html
from pathlib import Path
S=json.load(open('/workspace/scratch/ohm-a3/scene.json'))
OUT=Path('/workspace/shared/downloads/OhmHouse-A3'); SRC=OUT/'source'
of=lambda t:[n for n in S['nodes'].values() if n['type']==t and n.get('visible')!=False]
walls=of('wall'); rooms=of('zone'); slab=of('slab')[0]; cols=of('column')
for i,w in enumerate(walls):
 w['code']=f'WL{i+1:02}';w['L']=math.dist(w['start'],w['end']);w['angle']=math.atan2(w['end'][1]-w['start'][1],w['end'][0]-w['start'][0])
wm={w['id']:w for w in walls};ops=[]
for typ,prefix in [('door','D'),('window','W')]:
 for i,o in enumerate(of(typ)):
  o=dict(o);o['code']=f'{prefix}{i+1:02}';o['wall']=wm[o['wallId']];o['s']=o['position'][0];o['left']=o['s']-o['width']/2;o['right']=o['wall']['L']-o['s']-o['width']/2;o['sill']=o['position'][1]-o['height']/2;o['head']=o['sill']+o['height'];ops.append(o)
def area(p):return abs(sum(a[0]*p[(i+1)%len(p)][1]-p[(i+1)%len(p)][0]*a[1] for i,a in enumerate(p)))/2
rooms=[r for r in rooms if len(r['polygon'])>=3 and area(r['polygon'])>.001]
def safe(s):return html.escape(str(s))
def fmt(v):return f'{v:.3f}'
class Page:
 def __init__(self,num,title,subtitle):
  self.num=num;self.items=['<svg xmlns="http://www.w3.org/2000/svg" width="420mm" height="297mm" viewBox="0 0 420 297"><rect width="420" height="297" fill="white"/>']
  self.rect(8,8,404,281,stroke='#758087',sw=.22)
  self.text(14,18,'OHM HOUSE',5.5,bold=True)
  self.text(75,18,title,4.7,bold=True)
  self.text(14,26,subtitle,2.7)
  self.line((14,30),(406,30),'#758087',.22)
  self.line((14,264),(406,264),'#758087',.22)
  self.text(14,271,'ชุดแปลนประกอบการวางแผน • อ้างอิง Pascal V384 / ข้อมูล 11 ก.ย. 2026',2.6)
  self.text(14,277,'หน่วย: เมตร | พิมพ์ Actual size / 100% • ห้ามเลือก Fit to page',2.6)
  self.text(14,283,'ระยะตามไฟล์แบบ ไม่ใช่ระยะสุทธิหลังฉาบ • ตรวจหน้างานก่อนก่อสร้างหรือสั่งผลิต',2.4,color='#5c6469')
  self.text(406,273,f'A–{num:02} / 06',4,anchor='end',bold=True)
  self.text(406,280,'A3 • 420 × 297 มม.',2.8,anchor='end')
  self.line((204,276),(304,276),sw=.35)
  self.line((204,274),(204,278));self.line((304,274),(304,278))
  self.text(254,272,'ตรวจขนาดพิมพ์: เส้นนี้ต้องยาว 100 มม.',2.5,anchor='middle')
  self.text(254,283,'สร้างชุดเอกสาร 3 ต.ค. 2026',2.3,anchor='middle',color='#667077')
 def line(self,a,b,color='#253840',sw=.2,dash=None):
  self.items.append(f'<line x1="{a[0]:.4f}" y1="{a[1]:.4f}" x2="{b[0]:.4f}" y2="{b[1]:.4f}" stroke="{color}" stroke-width="{sw}"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>')
 def rect(self,x,y,w,h,fill='none',stroke='none',sw=.2):self.items.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
 def text(self,x,y,s,size=2.8,anchor='start',bold=False,color='#253840',rotate=None,halo=False):
  t=f' transform="rotate({rotate} {x} {y})"' if rotate is not None else ''
  haloattr=' stroke="white" stroke-width="1" paint-order="stroke" stroke-linejoin="round"' if halo else ''
  self.items.append(f'<text x="{x:.4f}" y="{y:.4f}" font-family="Noto Sans Thai, sans-serif" font-size="{size}" font-weight="{700 if bold else 400}" text-anchor="{anchor}" fill="{color}"{t}{haloattr}>{safe(s)}</text>')
 def poly(self,pts,fill='none',stroke='#253840',sw=.2):self.items.append('<polygon points="'+' '.join(f'{x:.4f},{y:.4f}' for x,y in pts)+f'" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
 def dim(self,a,b,offset,label=None,color='#394e59',size=2.7):
  dx=b[0]-a[0];dy=b[1]-a[1];L=math.hypot(dx,dy)
  if L<1e-8:return
  n=(dy/L,-dx/L);q=(a[0]+n[0]*offset,a[1]+n[1]*offset);r=(b[0]+n[0]*offset,b[1]+n[1]*offset)
  for v,z in [(a,q),(b,r)]:self.line(v,(z[0]+n[0]*1.3,z[1]+n[1]*1.3),'#829098',.12)
  self.line(q,r,color,.18)
  for p in [q,r]:self.line((p[0]-.75,p[1]+.75),(p[0]+.75,p[1]-.75),color,.2)
  theta=math.degrees(math.atan2(dy,dx))
  if theta>90:theta-=180
  if theta<-90:theta+=180
  self.text((q[0]+r[0])/2+n[0]*1.3,(q[1]+r[1])/2+n[1]*1.3,label or '',size,anchor='middle',rotate=theta,halo=True)
 def table(self,x,y,widths,headers,rows,rowh=6,size=2.5):
  total=sum(widths);self.rect(x,y,total,8,fill='#eaf0f2')
  xx=x
  for w,h in zip(widths,headers):self.text(xx+1.6,y+5.2,h,size,bold=True);xx+=w
  for i,row in enumerate(rows):
   yy=y+8+i*rowh
   if i%2==1:self.rect(x,yy,total,rowh,fill='#f6f8f9')
   xx=x
   for w,value in zip(widths,row):self.text(xx+1.6,yy+rowh*.7,value,size);xx+=w
   self.line((x,yy+rowh),(x+total,yy+rowh),'#d1d9dd',.1)
  return y+8+len(rows)*rowh
 def save(self):
  path=SRC/f'A{self.num:02}.svg';path.write_text(''.join(self.items)+'</svg>');return path

def inside(p,poly):
 x,y=p;c=False
 for i,a in enumerate(poly):
  b=poly[(i+1)%len(poly)]
  if ((a[1]>y)!=(b[1]>y)) and x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]:c=not c
 return c

def labelpoint(poly):
 # A point inside concave rooms, away from edges, instead of a bounding-box centre.
 best=None
 for i in range(1,31):
  for j in range(1,31):
   x=min(v[0] for v in poly)+(max(v[0] for v in poly)-min(v[0] for v in poly))*i/31
   y=min(v[1] for v in poly)+(max(v[1] for v in poly)-min(v[1] for v in poly))*j/31
   if not inside((x,y),poly):continue
   distances=[]
   for k,a in enumerate(poly):
    b=poly[(k+1)%len(poly)];dx=b[0]-a[0];dy=b[1]-a[1];t=max(0,min(1,((x-a[0])*dx+(y-a[1])*dy)/(dx*dx+dy*dy)))
    distances.append(math.hypot(x-a[0]-t*dx,y-a[1]-t*dy))
   score=min(distances)
   if best is None or score>best[0]:best=(score,(x,y))
 return best[1]

def baseplan(pg,origin=(43,55),scale=75,roomlabels=True,openinglabels=False,walllabels=False):
 k=1000/scale
 P=lambda p:(origin[0]+p[0]*k,origin[1]+p[1]*k)
 for r in rooms:
  pg.poly([P(v) for v in r['polygon']],fill='#eef4f6' if 'น้ำ' in r['name'] else '#f6f7f7',stroke='#d2dadf',sw=.13)
  if roomlabels:
   x,y=P(labelpoint(r['polygon']));pg.text(x,y,r['name'],2.8,anchor='middle',halo=True);pg.text(x,y+4,f'{area(r["polygon"]):.2f} ตร.ม.',2.25,anchor='middle',color='#63757e',halo=True)
 pg.poly([P(v) for v in slab['polygon']],stroke='#93a1a8',sw=.18)
 for w in walls:
  pg.line(P(w['start']),P(w['end']),'#354951',w['thickness']*k)
 for o in ops:
  w=o['wall'];c=math.cos(w['angle']);s=math.sin(w['angle']);along=lambda d:(w['start'][0]+c*d,w['start'][1]+s*d)
  a=P(along(o['left']));b=P(along(o['s']+o['width']/2));pg.line(a,b,'white',w['thickness']*k+.1);pg.line(a,b,'#366c84' if o['type']=='window' else '#956327',.5)
  if openinglabels:
   x,y=P(along(o['s']));offset=5 if o['sill']>=2.2 else 2.7;pg.text(x-s*offset,y+c*offset,o['code'],2.4,anchor='middle',color='#204a5f',halo=True)
 for c in cols:
  x,y=P((c['position'][0],c['position'][2]));cw=c.get('width',.2)*k;cd=c.get('depth',.2)*k;pg.rect(x-cw/2,y-cd/2,cw,cd,fill='#354951')
 if walllabels:
  for w in walls:
   a=P(w['start']);b=P(w['end']);dx=b[0]-a[0];dy=b[1]-a[1];l=math.hypot(dx,dy);n=(dy/l,-dx/l)
   # Small wall code and an arrow establish A to B consistently with the table.
   m=((a[0]+b[0])/2+n[0]*3.7,(a[1]+b[1])/2+n[1]*3.7)
   theta=math.degrees(w['angle']);theta=theta-180 if theta>90 else theta+180 if theta<-90 else theta
   pg.text(m[0],m[1],w['code'],2.6,anchor='middle',rotate=theta,halo=True)
   q=(a[0]+dx*.2+n[0]*1.6,a[1]+dy*.2+n[1]*1.6);r=(a[0]+dx*.8+n[0]*1.6,a[1]+dy*.8+n[1]*1.6)
   pg.line(q,r,'#52717f',.13)
   pg.poly([r,(r[0]-dx/l*1.6+n[0]*.6,r[1]-dy/l*1.6+n[1]*.6),(r[0]-dx/l*1.6-n[0]*.6,r[1]-dy/l*1.6-n[1]*.6)],fill='#52717f',stroke='none')
 return P

def scalebar(pg,x,y,scale=75):
 k=1000/scale
 for i in range(5):pg.rect(x+i*k,y,k,1.5,fill='#354951' if i%2==0 else 'white',stroke='#354951',sw=.15)
 for i in range(6):pg.text(x+i*k,y+5,str(i),2.3,anchor='middle')
 pg.text(x,y-2,f'มาตราส่วน 1:{scale} • แถบสเกล 0–5 เมตร',2.7,bold=True)

def roomdiagram(pg,r,cell):
 x,y,w,h=cell;k=1000/75;poly=r['polygon'];minx=min(v[0] for v in poly);minz=min(v[1] for v in poly);maxx=max(v[0] for v in poly);maxz=max(v[1] for v in poly)
 ox=x+(w-(maxx-minx)*k)/2;oy=y+16+(h-24-(maxz-minz)*k)/2
 P=lambda v:(ox+(v[0]-minx)*k,oy+(v[1]-minz)*k)
 pg.text(x+2,y+5,r['name'],3.5,bold=True);pg.text(x+w-2,y+5,'1:75',2.6,anchor='end')
 pg.poly([P(v) for v in poly],fill='#f2f6f7',stroke='#354951',sw=.45)
 for i,a in enumerate(poly):
  b=poly[(i+1)%len(poly)];pg.dim(P(a),P(b),5.7,fmt(math.dist(a,b)),size=2.8)
 cx,cy=P(labelpoint(poly));pg.text(cx,cy,f'{area(poly):.2f} ตร.ม.',2.9,anchor='middle')

